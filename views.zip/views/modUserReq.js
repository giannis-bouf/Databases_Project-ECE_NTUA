$(document).ready(function (){
    const home_button = document.getElementById('modTitle');
    home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });
  
    $.ajax({
      url:'/fetchModUsersUnver',
      method: 'GET',
      success: function(data) {
        const rowsData = data.usersDetails;
        console.log(rowsData);
    
        const RowContainer = document.querySelector('#RowContainer');
        RowContainer.innerHTML = '';
        for (let i = 0; i < rowsData.length; i++) {
          const row = rowsData[i];
    
          // Create a new row element
          const rowElement = createRowElement(row, i);
          RowContainer.appendChild(rowElement);
        }
    
          function createRowElement(row, i) {
            const rowElement = document.createElement('tr');
            rowElement.innerHTML = `
            <th scope="row">${i+1}</th>
            <td>${row.first_name}</td>
            <td>${row.last_name}</td>
            <td>${row.email}</td>
            <td>${row.role}</td>
            <td>${row.birthdate}</td>
            <td>${row.telephone}</td>
            <td>${row.address}</td>
            <td><button class="btn btn-primary" id="cancel_button">Verify</button></td>`;
          
            rowElement.addEventListener('click', function(event) {
              if (event.target.id === 'cancel_button') {
                $.ajax({
                  url:'/verUsers',
                  method: 'POST',
                  data: { user_id: row.user_id },
                  success: function(data) {
                    // Store the clicked book data in local storage
                    localStorage.setItem('row', JSON.stringify(row));

                    window.location.href = 'CreateCard.html';
                  },
                  error: function(error) {
                    console.log('Error fetching book data:', error);
                  }
                  });
              }
            });
      
          return rowElement;
      }
    },
      error: function(error) {
        console.log('Error fetching book data:', error);
      }
    });
})