$(document).ready(function (){
    const home_button = document.getElementById('modTitle');
    home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });

    $.ajax({
        url:'/fetchCategRate',
        method: 'GET',
        success: function(data) {
          const rowsData = data.CatRatsData;
          console.log(rowsData);
      
          const RowContainer = document.querySelector('#RowContainer');
          RowContainer.innerHTML = '';
            for (let i = 0; i < rowsData.length; i++) {
            const row = rowsData[i];
      
            // Create a new row element
              const rowElement = createRowElement(row, i);
              RowContainer.appendChild(rowElement);

      
            function createRowElement(row, i) {
              const rowElement = document.createElement('tr');
              rowElement.innerHTML = `
              <th scope="row">${i+1}</th>
              <td>${row.category}</td>
              <td>${row.average_rating}</td>
              `;
        
            return rowElement;
            }
          }
        },
        error: function(error) {
          console.log('Error fetching book data:', error);
        }
      });
  })