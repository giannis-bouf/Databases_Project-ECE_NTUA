const profile = document.getElementById('profile');
profile.addEventListener('click', function() { window.location.href = 'UserProfile.html'; });


$.ajax({
  url:'/myRen',
  method: 'GET',
  success: function(data) {
    const rowsData = data.rensData;
    console.log(rowsData);

    const RowContainer = document.querySelector('#RowContainer');
    RowContainer.innerHTML = '';
      for (let i = 0; i < rowsData.length; i++) {
      const row = rowsData[i];

      // Create a new row element
        const rowElement = createRowElement(row, i);
        RowContainer.appendChild(rowElement);


      function createRowElement(row, i) {
        const rowElement = document.createElement('tr');
        rowElement.innerHTML = `
        <th scope="row">${i+1}</th>
        <td>${row.title}</td>
        <td>${row.take_date}</td>
        <td>${row.status}</td>
        `;

        return rowElement;
      }
    }
  },
  error: function(error) {
    console.log('Error fetching book data:', error);
  }
});