$(document).ready(function (){
    const logout_button = document.getElementById('modTitle');
    logout_button.addEventListener('click', function() { window.location.href = 'index.html'; });

    const PerMonth = document.getElementById('PerMonth');
    PerMonth.addEventListener('click', function() { window.location.href = 'rentals_per_month.html'; });

    const No_Rent = document.getElementById('Delays');
    No_Rent.addEventListener('click', function() { window.location.href = 'no_rental_authors.html'; });
    const No_Rent_fast = document.getElementById('Delays_fast');
    No_Rent_fast.addEventListener('click', function() { window.location.href = 'no_rental_authors.html'; });

    const Top_3 = document.getElementById('Users');
    Top_3.addEventListener('click', function() { window.location.href = 'top_3.html'; });
    const Top_3_fast = document.getElementById('Users_fast');
    Top_3_fast.addEventListener('click', function() { window.location.href = 'top_3.html'; });   

    const More_than_20 = document.getElementById('books1');
    More_than_20.addEventListener('click', function() { window.location.href = 'more_than_20.html'; });
    const More_than_20_fast = document.getElementById('books1_fast');
    More_than_20_fast.addEventListener('click', function() { window.location.href = 'more_than_20.html'; });  

    const Category_stats = document.getElementById('RentalHistory');
    Category_stats.addEventListener('click', function() { window.location.href = 'category_stats.html'; });
    const Category_stats_fast = document.getElementById('RentalHistory_fast');
    Category_stats_fast.addEventListener('click', function () { window.location.href = 'category_stats.html'; }); 

    const Young_readers = document.getElementById('YoungReaders');
    Young_readers.addEventListener('click', function () { window.location.href = 'youngreaders.html'; });
    const Young_readers_fast = document.getElementById('YoungReaders_fast');
    Young_readers_fast.addEventListener('click', function () { window.location.href = 'youngreaders.html'; });

    const five_to_the_top = document.getElementById('5_to_the_top');
    five_to_the_top.addEventListener('click', function () { window.location.href = '5tothetop.html'; });
    const five_to_the_top_fast = document.getElementById('5_to_the_top_fast');
    five_to_the_top_fast.addEventListener('click', function () { window.location.href = '5tothetop.html'; });

    const NewUsersRequest = document.getElementById('NewUsersRequest');
    NewUsersRequest.addEventListener('click', function () { window.location.href = 'mod_handling_in_admin.html'; });
    const NewUsersRequest_fast = document.getElementById('NewUsersRequest_fast');
    NewUsersRequest_fast.addEventListener('click', function () { window.location.href = 'mod_handling_in_admin.html'; });

    const Returns2 = document.getElementById('Returns2');
    Returns2.addEventListener('click', function () { window.location.href = 'new_school.html'; });
    const Returns2_fast = document.getElementById('Returns2_fast');
    Returns2_fast.addEventListener('click', function () { window.location.href = 'new_school.html'; });
});