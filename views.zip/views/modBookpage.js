$(document).ready(function (){
  const home_button = document.getElementById('modTitle');
  home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });
    
  const CreateNewBook = document.getElementById('CreateNewBook');
  CreateNewBook.addEventListener('click', function() { window.location.href = 'NewBook.html'; });

  $.ajax({
    url:'/fetchModBooks',
    method: 'GET',
    success: function(data) {
      const rowsData = data.booksDetails;
      console.log(rowsData);
  
      const RowContainer = document.querySelector('#RowContainer');
      RowContainer.innerHTML = '';
        for (let i = 0; i < rowsData.length; i++) {
        const row = rowsData[i];
  
        // Create a new row element
        const rowElement = createRowElement(row, i);
        
        // Append the row to the book container
        RowContainer.appendChild(rowElement);
        }
  
        function createRowElement(row, i) {
          const rowElement = document.createElement('tr');
          rowElement.innerHTML = `
          <th scope="row">${i+1}</th>
            <td>${row.title}</td>
            <td>${row.authorName}</td>
            <td>${row.categoryName}</td>
            <td>${row.totalCopies}</td>
            <td>${row.availableCopies}</td>
            <td>${row.activeRentals}</td>
            <td>${row.activeReservations}</td>
            <td><button class="btn btn-primary" id="submit_button">Edit</button></td>`;
        
        rowElement.addEventListener('click', function() {
        // Store the clicked book data in local storage
        localStorage.setItem('row', JSON.stringify(row));
      
         // Redirect to bookpage.html
        window.location.href = 'modifyBook.html';
        });
    
        return rowElement;
    }
  },
    error: function(error) {
      console.log('Error fetching book data:', error);
    }
  });

  $('form').submit(function(event) {
    event.preventDefault(); // Prevent the form from submitting and reloading the page
    
    const word = $('#input_title').val(); // Get the value of the input field
    const author = $('#input_author').val(); // Get the selected author value from the dropdown
    const categories = $('#input_categories').val(); // Get the selected author value from the dropdown
    const copies = $('#input_copies').val(); // Get the selected author value from the dropdown

    // Perform the AJAX request with the input word as a query parameter
    $.ajax({
        url: '/fetchModBooks',
        method: 'GET',
        data: { word: word || undefined, // Pass the input word as a query parameter or undefined if empty
                author: author || undefined, // Pass the selected author as a query parameter or undefined if empty
                categories: categories || undefined, 
                copies: copies || undefined
            },
        success: function(data) {
      
        const rowsData = data.booksDetails;
        console.log(rowsData);
    
        const RowContainer = document.querySelector('#RowContainer');
        RowContainer.innerHTML = '';
          for (let i = 0; i < rowsData.length; i++) {
          const row = rowsData[i];
    
          // Create a new row element
          const rowElement = createRowElement(row, i);
          
          // Append the row to the book container
          RowContainer.appendChild(rowElement);
          }
    
          function createRowElement(row, i) {
            const rowElement = document.createElement('tr');
            rowElement.innerHTML = `
            <th scope="row">${i+1}</th>
              <td>${row.title}</td>
              <td>${row.authorName}</td>
              <td>${row.categoryName}</td>
              <td>${row.totalCopies}</td>
              <td>${row.availableCopies}</td>
              <td>${row.activeRentals}</td>
              <td>${row.activeReservations}</td>
              <td><button class="btn btn-primary" id="submit_button">Edit</button></td>`;
          
          rowElement.addEventListener('click', function() {
          // Store the clicked book data in local storage
          localStorage.setItem('row', JSON.stringify(row));
        
           // Redirect to bookpage.html
          window.location.href = 'modifyBook.html';
          });
      
          return rowElement;
        }
        // Rest of your code to update the book list view
        },
    error: function(error) {
      console.log('Error fetching book data:', error);
    }
    });
  });

  $('#AuthorsApplybtn').click(function() {
    // Add event listeners to the dropdown items
    const dropdownItems = document.querySelectorAll('#author_dropdown .dropdown-item');
    dropdownItems.forEach(item => {
        item.addEventListener('click', function() {
        const author = item.id; // Retrieve the ID of the clicked item
        console.log(selectedAuthor); // Perform any further actions with the selected author
        });
    });


    // Perform the AJAX request with the input word as a query parameter
    $.ajax({
        url: '/fetchModBooks',
        method: 'GET',
        data: { author: author || undefined // Pass the input word as a query parameter or undefined if empty
        },
    success: function(data) {
      
        const rowsData = data.booksDetails;
        console.log(rowsData);
    
        const RowContainer = document.querySelector('#RowContainer');
        RowContainer.innerHTML = '';
          for (let i = 0; i < rowsData.length; i++) {
          const row = rowsData[i];
    
          // Create a new row element
          const rowElement = createRowElement(row, i);
          
          // Append the row to the book container
          RowContainer.appendChild(rowElement);
          }
    
          function createRowElement(row, i) {
            const rowElement = document.createElement('tr');
            rowElement.innerHTML = `
            <th scope="row">${i+1}</th>
              <td>${row.title}</td>
              <td>${row.authorName}</td>
              <td>${row.categoryName}</td>
              <td>${row.totalCopies}</td>
              <td>${row.availableCopies}</td>
              <td>${row.activeRentals}</td>
              <td>${row.activeReservations}</td>
              <td><button class="btn btn-primary" id="submit_button">Edit</button></td>`;
          
          rowElement.addEventListener('click', function() {
          // Store the clicked book data in local storage
          localStorage.setItem('row', JSON.stringify(row));
           // Redirect to bookpage.html
          window.location.href = 'modifyBook.html';
          });
      
          return rowElement;
        }
        // Rest of your code to update the book list view
        },
    error: function(error) {
      console.log('Error fetching book data:', error);
    }
    });
  })
})
