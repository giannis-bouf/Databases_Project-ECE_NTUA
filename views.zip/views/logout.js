$('#logoutButton').on('click', function() {
    // Send a request to the logout endpoint
    $.ajax({
      url: '/logout',
      method: 'GET',
      success: function(response) {
        // Redirect to the login page
        window.location.href = 'index.html';
      },
      error: function(error) {
        console.error(error);
      }
    });
  });
  