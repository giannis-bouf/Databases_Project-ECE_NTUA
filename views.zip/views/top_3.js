$(document).ready(function (){
    const logout_button = document.getElementById('modTitle');
    logout_button.addEventListener('click', function() { window.location.href = 'home_of_admin.html'; });

    $.ajax({
        url:'/fetchTopCategoriesPairs',
        method: 'GET',
        success: function(data) {
          const rowsData = data.TCPsData;
          console.log(rowsData);
      
          const RowContainer = document.querySelector('#RowContainer');
          RowContainer.innerHTML = '';
            for (let i = 0; i < rowsData.length; i++) {
            const row = rowsData[i];
      
            // Create a new row element
            const rowElement = createRowElement(row, i);
            
            // Append the row to the book container
            RowContainer.appendChild(rowElement);
            }
      
            function createRowElement(row, i) {
              const rowElement = document.createElement('tr');
              rowElement.innerHTML = `
                <th scope="row">${i+1}</th>
                <td>${row.pair}</td>
                <td>${row.total_rentals}</td>`;
              return rowElement;
        }
      },
        error: function(error) {
          console.log('Error fetching book data:', error);
        }
      });
});