// Function to redirect to a different page
function redirectToPage(page) {
    window.location.href = page;
}



$(document).ready(function (){
    $('#loginForm').on('submit', function (event) {
        event.preventDefault();

        const username = $('#inputUsername').val();
        const password = $('#inputPassword').val();

        $.ajax({
            url: '/',
            method: 'POST',
            data: { username, password},
            success: function (response) {
                if (response.role === 'user') {
                //Handle successfu; login response
                redirectToPage('homepage.html');
                //redirect to the home page
              // window.location.href = '/home';
            } else if (response.role === 'moderator'){
               
                redirectToPage('modhome.html');
            } else if (response.role === 'admin'){
               
                redirectToPage('home_of_admin.html');
            } else {
                console.log('unknown role');
            }
        }
        });
    });
});