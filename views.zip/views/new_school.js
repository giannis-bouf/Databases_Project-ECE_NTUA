$(document).ready(function (){
    const logout_button = document.getElementById('modTitle');
    logout_button.addEventListener('click', function() { window.location.href = 'home_of_admin.html'; });

    const SaveNewBook = document.getElementById('SaveNewBook');
    SaveNewBook.addEventListener('click', function() {
    
    const NewSchoolData = {
        school: $('#school').val(),
        address: $('#address').val(),
        city: $('#city').val(),
        postal_code: $('#pc').val(),
        telephone: $('#telephone').val(),
        email: $('#email').val(),
        principal: $('#principal').val()
    };
    
    //send the form data to the server for further proccessing
    $.ajax({
        url: '/CreateNewSchool',
        method: 'POST',
        data: NewSchoolData,
        success: function(response) {
            window.location.href = 'home_of_admin.html';
        },
        error: function (xhr, status, error) {
            console.error(xhr.responseText);
        }
    });
    
    });
})