$(document).ready(function (){
    const home_button = document.getElementById('modTitle');
    home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });
  
    $.ajax({
      url:'/fetchModUsers',
      method: 'GET',
      success: function(data) {
        const rowsData = data.usersDetails;
        console.log(rowsData);
    
        const RowContainer = document.querySelector('#RowContainer');
        RowContainer.innerHTML = '';
          for (let i = 0; i < rowsData.length; i++) {
          const row = rowsData[i];
    
          // Create a new row element
          if(row.active_rents > 0) {
            const rowElement = createRowElement(row, i);
            RowContainer.appendChild(rowElement);
        }
          else {
            const rowElementWithout = createRowElementWithoutRental(row, i);
            RowContainer.appendChild(rowElementWithout);
        }
          
          // Append the row to the book container
        }
    
          function createRowElement(row, i) {
            const rowElement = document.createElement('tr');
            rowElement.innerHTML = `
            <th scope="row">${i+1}</th>
            <td>${row.first_name}</td>
            <td>${row.last_name}</td>
            <td>${row.email}</td>
            <td>${row.role}</td>
            <td>${row.birthdate}</td>
            <td>${row.telephone}</td>
            <td>${row.address}</td>`
    
            if (row.average_rating) {rowElement.innerHTML += `<td>${row.average_rating}</td>`;}
            else {rowElement.innerHTML += `<td>No ratings yet</td>`;}
            
            rowElement.innerHTML += `<td><button class="btn btn-primary" id="cancel_button" style="background: red;">Cancel</button></td>`;
          
            rowElement.addEventListener('click', function(event) {
              if (event.target.id === 'rental_ac') {
                localStorage.setItem('row', JSON.stringify(row));
                window.location.href = 'modifyBook.html';
              }
              else if (event.target.id === 'rental_his') {
                localStorage.setItem('row', JSON.stringify(row));
                window.location.href = 'modifyBook.html';
              }
              else if (event.target.id === 'reserv_his') {
                localStorage.setItem('row', JSON.stringify(row));
                window.location.href = 'modifyBook.html';
              }
              else if (event.target.id === 'cancel_button') {
                $.ajax({
                  url:'/cancelUsers',
                  method: 'POST',
                  data: { user_id: row.user_id },
                  success: function(data) {
                    window.location.href = 'modhome.html';
                  },
                  error: function(error) {
                    console.log('Error fetching book data:', error);
                  }
                  });
              }
            });
      
          return rowElement;
      }
      
      function createRowElementWithoutRental(row, i) {
        const rowElement = document.createElement('tr');
        rowElement.innerHTML = `
        <th scope="row">${i+1}</th>
        <td>${row.first_name}</td>
        <td>${row.last_name}</td>
        <td>${row.email}</td>
        <td>${row.role}</td>
        <td>${row.birthdate}</td>
        <td>${row.telephone}</td>
        <td>${row.address}</td>`;

        if (row.average_rating) {rowElement.innerHTML += `<td>${row.average_rating}</td>`;}
        else {rowElement.innerHTML += `<td>No ratings yet</td>`;}
            
        rowElement.innerHTML += `<td><button class="btn btn-primary" id="cancel_button" style="background: red;">Cancel</button></td>`;

        rowElement.addEventListener('click', function(event) {
          if (event.target.id === 'rental_his') {
            localStorage.setItem('row', JSON.stringify(row));
            window.location.href = 'modifyBook.html';
          }
          else if (event.target.id === 'reserv_his') {
            localStorage.setItem('row', JSON.stringify(row));
            window.location.href = 'modifyBook.html';
          }
          else if (event.target.id === 'cancel_button') {
            $.ajax({
              url:'/cancelUsers',
              method: 'POST',
              data: { user_id: row.user_id },
              success: function(data) {
                window.location.href = 'modhome.html';
              },
              error: function(error) {
                console.log('Error fetching book data:', error);
              }
              });
          }
        });
  
      return rowElement;
  }
    },
      error: function(error) {
        console.log('Error fetching book data:', error);
      }
    });
  
    $('form').submit(function(event) {
      event.preventDefault(); // Prevent the form from submitting and reloading the page
      
      const name = $('#input_name').val(); // Get the selected author value from the dropdown
  
      // Perform the AJAX request with the input word as a query parameter
      $.ajax({
          url: '/fetchModUsers',
          method: 'GET',
          data: { name: name || undefined },
          success: function(data) {
        
            const rowsData = data.usersDetails;
            console.log(rowsData);
        
            const RowContainer = document.querySelector('#RowContainer');
            RowContainer.innerHTML = '';
              for (let i = 0; i < rowsData.length; i++) {
              const row = rowsData[i];
        
              // Create a new row element
              if(row.active_rents > 0) {
                const rowElement = createRowElement(row, i);
                RowContainer.appendChild(rowElement);
            }
              else {
                const rowElementWithout = createRowElementWithoutRental(row, i);
                RowContainer.appendChild(rowElementWithout);
            }
              
              // Append the row to the book container
            }
        
              function createRowElement(row, i) {
                const rowElement = document.createElement('tr');
                rowElement.innerHTML = `
                <th scope="row">${i+1}</th>
                <td>${row.first_name}</td>
                <td>${row.last_name}</td>
                <td>${row.email}</td>
                <td>${row.role}</td>
                <td>${row.birthdate}</td>
                <td>${row.telephone}</td>
                <td>${row.address}</td>
                <td><button class="btn InTableBtn ActiveRental" type="button" >Show</button></td>
                <td><button class="btn InTableBtn RentalHistoryBtn" type="button" data-toggle="modal" data-target="#RentalHistoryModal">Show</button></td>
                <td><button class="btn InTableBtn ActiveReserveBtn" type="button">Show</button></td> 
                <td>${row.average_rating}</td>
                <td><button class="btn btn-primary" id="cancel_button" style="background: red;">Cancel</button></td>`;
              
                rowElement.addEventListener('click', function(event) {
                  if (event.target.id === 'cancel_button') {
                    $.ajax({
                      url:'/cancelUsers',
                      method: 'POST',
                      data: { user_id: row.user_id },
                      success: function(data) {
                        window.location.href = 'modhome.html';
                      },
                      error: function(error) {
                        console.log('Error fetching book data:', error);
                      }
                      });
                  }
                });
          
              return rowElement;
          }
          
          function createRowElementWithoutRental(row, i) {
            const rowElement = document.createElement('tr');
            rowElement.innerHTML = `
            <th scope="row">${i+1}</th>
            <td>${row.first_name}</td>
            <td>${row.last_name}</td>
            <td>${row.email}</td>
            <td>${row.role}</td>
            <td>${row.birthdate}</td>
            <td>${row.telephone}</td>
            <td>${row.address}</td>
            <td></td>
            <td><button class="btn InTableBtn RentalHistoryBtn" type="button" data-toggle="modal" data-target="#RentalHistoryModal">Show</button></td>
            <td><button class="btn InTableBtn ActiveReserveBtn" type="button">Show</button></td> 
            <td>${row.average_rating}</td>
            <td><button class="btn btn-primary" id="cancel_button" style="background: red;">Cancel</button></td>`;
          
            rowElement.addEventListener('click', function(event) {
                if (event.target.id === 'cancel_button') {
                  $.ajax({
                    url:'/cancelUsers',
                    method: 'POST',
                    data: { user_id: row.user_id },
                    success: function(data) {
                      window.location.href = 'modhome.html';
                    },
                    error: function(error) {
                      console.log('Error fetching book data:', error);
                    }
                    });
                }
            });
      
          return rowElement;
      }
        
          },
      error: function(error) {
        console.log('Error fetching book data:', error);
      }
      });
    });
})