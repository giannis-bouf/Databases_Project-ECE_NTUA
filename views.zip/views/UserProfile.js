$.ajax({
    url:'/profil',
    method: 'GET',
    success: function(response) {
        const data = response.responseData; // Access the nested responseData object
    console.log(data);
 
      


       // Generate the HTML code with the retrieved values
  const html = `
  <form>
    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="name">Όνομα</label>
        <input type="text" class="form-control" id="name" value="${data.firstName}" readonly>
      </div>
      <div class="form-group col-md-6">
        <label for="lastname">Επώνυμο</label>
        <input type="text" class="form-control" id="lastname" value="${data.lastName}" readonly>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="inputEmail">Email</label>
        <input type="email" class="form-control" id="inputEmail" value="${data.email}" readonly>
      </div>
      <div class="form-group col-md-6">
        <label for="username">Όνομα Χρήστη</label>
        <input type="text" class="form-control" id="username" value="${data.username}" readonly>
      </div>
    </div>
    <div class="form-group">
      <label for="inputschool">Σχολείο</label>
      <input type="text" class="form-control" id="inputschool" value="${data.schoolName}" readonly>
    </div>
    <div class="form-group">
      <label for="inputAddress">Διεύθυνση</label>
      <input type="text" class="form-control" id="inputAddress" value="${data.address}" readonly>
    </div>
    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="inputCity">Πόλη</label>
        <input type="text" class="form-control" id="inputCity" value="${data.city}" readonly>
      </div>
      <div class="form-group col-md-2">
        <label for="inputZip">TK</label>
        <input type="text" class="form-control" id="inputZip" value="${data.postalCode}" readonly>
      </div>
    </div>
    <button type="submit" class="btn btn-primary" style="margin-top: 15px; display: none;" id="submitButton">Ανανέωση</button>
  </form>
`;

// Replace the existing form with the dynamically generated HTML
$('#formContainer').html(html);

if (data.role) {
    console.log("User role:", data.role);
    $('#EditInfoBtn').toggle(data.role === 'teacher');
  }
  $(document).ready(function() {
    // Add event listener to the form submit button
    $('#submitButton').on('click', function(e) {
      e.preventDefault(); // Prevent the default form submission
  
      // Get the values from the input fields
      const firstName = $('#name').val();
      const lastName = $('#lastname').val();
      const email = $('#inputEmail').val();
      const username = $('#username').val();
      const schoolName = $('#inputschool').val();
      const address = $('#inputAddress').val();
      const city = $('#inputCity').val();
      const postalCode = $('#inputZip').val();
      
      // Create an object with the form data
      const formData = {
        firstName,
        lastName,
        email,
        username,
        schoolName,
        address,
        city,
        postalCode
      };
  
      // Send the form data to the server using AJAX
      $.ajax({
        url: '/update-profile',
        method: 'POST',
        data: formData,
        success: function(response) {
          // Handle the success response
          console.log(response);
          // Do any additional actions after the profile is updated
        },
        error: function(error) {
          // Handle the error response
          console.error(error);
          // Display an error message or take appropriate action
        }
      });
    });
  });
  $(document).ready(function() {
    $('#SetNewPassword').click(function() {
      // Get the entered password from the input field
      const enteredPassword = $('#Searchbar').val();
  
      // Get the password from the data object received from the server
      const correctPassword = data.password;
  
      // Compare the entered password with the correct password
      if (enteredPassword === correctPassword) {
        // Passwords match, do something
        console.log('Password is correct');
        $('#Password_check').hide();
        $('#Update_password').show();
      } else {
        // Passwords do not match, do something else
        console.log('Password is incorrect');

      }
    });
  });

  $(document).ready(function() {
    $('#Update_password form').submit(function(event) {
      event.preventDefault(); // Prevent the default form submission
  
      // Get the entered passwords from the input fields
      const newPassword = $('#newPassword').val();
      const checkNewPassword = $('#CheckNewPassword').val();
  
      // Check if the passwords match
      if (newPassword !== checkNewPassword) {
        // Passwords do not match, handle the error
        console.log('Passwords do not match');
        return; // Exit the function, no further action
      }
  
      // Passwords match, proceed with sending the request to the server
      const requestData = {
        newPassword: newPassword
      };
  
      // Send the request to the server
      $.ajax({
        url: '/update-password',
        method: 'POST',
        data: requestData,
        success: function(response) {
          // Password updated successfully, handle the response
          console.log('Password updated successfully');
        },
        error: function(error) {
          // Error occurred while updating the password, handle the error
          console.error('Error updating password:', error);
        }
      });
    });
  });    
}, 
    error: function (error) {
        console.error(error);
       
    }
});
