$(document).ready(function() {
    // Retrieve the clicked book data from local storage
    const row = JSON.parse(localStorage.getItem('row'));

    if (row) {
        const home_button = document.getElementById('modTitle');
        home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });
        const PrintBtn = document.getElementById('PrintBtn');
        PrintBtn.addEventListener('click', function() { window.location.href = 'modhome.html'; });

        const place = document.getElementById('cardElement');
        const card = document.createElement('div');
        card.innerHTML = `
        <div class="d-flex">
            <div id="photoRect" style="width: 130px;
            height: 153px;
            background: #FFFFFF;
            margin-left: 35px;
            margin-top: 26px;"></div>
                <div class="row" style="margin-top: 25px; margin-left: 45px;
                font-family: 'Roboto';
                font-style: normal;
                font-weight: 400;
                font-size: 40px;
                line-height: 47px;
                color: #000000;
                ">
                    <div id="FullName">${row.first_name} ${row.last_name}</div> 
                    <div id="Userid">User_id: #${row.user_id}</div>   
                </div>
            </div>
            <div class="row" id="schoolName" style="margin-left: 35px;
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            font-size: 40px;
            line-height: 47px;
            color: #000000;
            margin-top: 15px;">${row.school}</div>
            <div class="row" style="font-family: 'Roboto';
            font-style: italic;
            font-weight: 600;
            font-size: 30px;
            line-height: 35px;
            color: #000000;
            margin-top: 33px;
            margin-left: 50px;">User's Club Card</div>
        `;

        place.appendChild(card);
    } else {
        // Book data not found in local storage
        console.log('Book data not available.');
  }
})