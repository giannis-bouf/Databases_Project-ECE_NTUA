$(document).ready(function (){
    const logout_button = document.getElementById('modTitle');
    logout_button.addEventListener('click', function() { window.location.href = 'index.html'; });

    const Books1 = document.getElementById('books1');
    Books1.addEventListener('click', function() { window.location.href = 'modBookpage.html'; });
    const Books2 = document.getElementById('books2');
    Books2.addEventListener('click', function() { window.location.href = 'modBookpage.html'; });

    const Users = document.getElementById('Users');
    Users.addEventListener('click', function() { window.location.href = 'modUserpage.html'; });
    const Users_fast = document.getElementById('Users_fast');
    Users_fast.addEventListener('click', function() { window.location.href = 'modUserpage.html'; });

    const newUsers = document.getElementById('NewUsersRequest');
    newUsers.addEventListener('click', function() { window.location.href = 'modUserReq.html'; });
    const newUsers_fast = document.getElementById('NewUsersRequest_fast');
    newUsers_fast.addEventListener('click', function() { window.location.href = 'modUserReq.html'; });

    const Returns2 = document.getElementById('Returns2');
    Returns2.addEventListener('click', function() { window.location.href = 'RentalRequest.html'; });
    const Returns2_fast = document.getElementById('Returns2_fast');
    Returns2_fast.addEventListener('click', function() { window.location.href = 'RentalRequest.html'; });

    const ReserveRequests = document.getElementById('ReserveRequests');
    ReserveRequests.addEventListener('click', function() { window.location.href = 'ReserveRequest.html'; });
    const ReserveRequests_fast = document.getElementById('ReserveRequests_fast');
    ReserveRequests_fast.addEventListener('click', function() { window.location.href = 'ReserveRequest.html'; });

    const Ratings = document.getElementById('Ratings');
    Ratings.addEventListener('click', function() { window.location.href = 'RatingsApproval.html'; });

    const RentalHistory = document.getElementById('RentalHistory');
    RentalHistory.addEventListener('click', function() { window.location.href = 'modRentalHistory.html'; });
    const RentalHistory_fast= document.getElementById('RentalHistory_fast');
    RentalHistory_fast.addEventListener('click', function() { window.location.href = 'modRentalHistory.html'; });

    const Delays = document.getElementById('Delays');
    Delays.addEventListener('click', function() { window.location.href = 'Delays.html'; });
    const Delays_fast= document.getElementById('Delays_fast');
    Delays_fast.addEventListener('click', function() { window.location.href = 'Delays.html'; });

    const ReserveHistory = document.getElementById('ReserveHistory');
    ReserveHistory.addEventListener('click', function() { window.location.href = 'modResHistory.html'; });
    const ReserveHistory_fast= document.getElementById('ReserveHistory_fast');
    ReserveHistory_fast.addEventListener('click', function() { window.location.href = 'modResHistory.html'; });
});
