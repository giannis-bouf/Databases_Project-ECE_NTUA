$(document).ready(function (){
    const profile = document.getElementById('profile');
    profile.addEventListener('click', function() { window.location.href = 'UserProfile.html'; });

    $.ajax({
        url:'/myRes',
        method: 'GET',
        success: function(data) {
          const rowsData = data.ressData;
          console.log(rowsData);
      
          const RowContainer = document.querySelector('#RowContainer');
          RowContainer.innerHTML = '';
            for (let i = 0; i < rowsData.length; i++) {
            const row = rowsData[i];
      
            // Create a new row element
              const rowElement = createRowElement(row, i);
              RowContainer.appendChild(rowElement);

      
            function createRowElement(row, i) {
              const rowElement = document.createElement('tr');
              rowElement.innerHTML = `
              <th scope="row">${i+1}</th>
              <td>${row.title}</td>
              `;
              
              if (row.status == 'active') {rowElement.innerHTML += `<td>${row.reserved_for}</td>`}
              else {rowElement.innerHTML += `<td> </td>`}
              
              rowElement.innerHTML += `
              <td>${row.status}</td>
              <td><button class="btn InTableBtn Deny" id="decline" type="button" style="background:#F25A5A;">Cancel</button></td>
              `;
            
              rowElement.addEventListener('click', function(event) {
                if (event.target.id === 'decline') {
                    $.ajax({
                      url:'/decRes',
                      method: 'POST',
                      data: { rent_id: row.rent_id },
                      success: function(data) {
                        window.location.href = 'homePage.html';
                      },
                      error: function(error) {
                        console.log('Error fetching book data:', error);
                      }
                      });
                  }
              });
        
            return rowElement;
            }
          }
        },
        error: function(error) {
          console.log('Error fetching book data:', error);
        }
      });
})