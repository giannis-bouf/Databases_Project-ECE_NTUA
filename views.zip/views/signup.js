let selectedRole = ''; 
let selectedSchoolId = '';
let birthDate = '';

//Get the input element
const birthDateInput = document.getElementById('birth-date');
// add event listener for when the input value change
birthDateInput.addEventListener('input', function() {
    birthDate = this.value;
    console.log(birthDate);
})
// Function to show the message div

function showMessageDiv(message) {
    const messageDiv = document.getElementById("username_availability");
    messageDiv.innerHTML = message;
    messageDiv.style.display = "block";
}


// Function to redirect to a different page
function redirectToPage(page) {
    window.location.href = page;
}

// Fetch schools and populate the options
function fetchSchools() {
    $.ajax({
        url:'/schools',
        method: 'GET',
        success: function(response) {
           // console.log(response);
            const schools = response;

            //Generate the options dynamically
            const selectElement = $('#school-select');
            selectElement.empty();
            selectElement.append('<option selected> Select School</option');
            schools.forEach(function(school) {
                selectElement.append('<option value="' + school.id + '">' + school.name + '</option>');     
            });
            selectElement.change(function() {
                selectedSchoolId = $(this).val();
            });
        },
        error: function(xhr, status, error){
            console.error(xhr.responseText);
        }
    });
}


// Fetch school options when the page loads 
$(document).ready(function() {
    fetchSchools();
});

// event listener for role selection
$('#role-select').change(function() {
    selectedRole = $(this).val();
});



//Form submission 
$('#signup-form').submit(function(event) {
event.preventDefault();

const formData = {
    firstName: $('#inputName').val(),
    lastName: $('#inputLastname').val(),
    username: $('#username').val(),
    email: $('#inputEmail').val(),
    password: $('#password').val(),
    role: selectedRole,
    schoolId: selectedSchoolId,
    birthDate: birthDate,
    phone: $('#inputPhone').val(),
    address: $('#inputAddress').val(),
    postal_code: $('#inputPC').val(),
    city: $('#inputCity').val()
};

//send the form data to the server for further proccessing
$.ajax({
    url: '/signup',
    method: 'POST',
    data: formData,
    success: function(response) {
        if (response.message === 'Username already exists') {
            showMessageDiv("Username is already taken. Please choose another one.");
        } else {
            redirectToPage('index.html');
        }
    },
    error: function (xhr, status, error) {
        console.error(xhr.responseText);
    }
});

});

