// User List Page

$(document).ready(function() {
  let selectedUserID = null;
  let rentalHistory = []; // Variable to store the fetched rental history data
  let isOnlyActiveVisible = false; // Variable to track if only active rentals are visible

  // AJAX request to fetch user data
  $.ajax({
    url: '/RentalHistory',
    method: 'GET',
    success: function(response) {
      const users = response.users;
      console.log(users);
      const usersList = document.getElementById('UsersList');
      const userListHTML = users.map(user => {
        return `
          <li class="User-item" style="font-family: 'Roboto';
          font-style: normal;
          font-weight: 600;
          font-size: 20px;">
            <input type="radio" id="user_${user.userID}" name="user" class="regular-radio">
            <label for="user_${user.userID}" class="userName"><br>${user.firstName} ${user.lastName}, ${user.username}</label>
          </li>
        `;
      }).join('');

      usersList.innerHTML = `<ul style="list-style: none;">${userListHTML}</ul>`;

      // Add event listener to user selection
      $('input[name="user"]').on('change', function() {
        selectedUserID = this.id.split('_')[1];
      });

      const userApplyBtn = document.getElementById('UserApplybtn');
      const rentalHistoryTable = document.getElementById('rentalTable');
       const showOnlyActiveBtn = document.getElementById('ShowOnlyActive');
      // Add event listener to the Apply button
      userApplyBtn.addEventListener('click', () => {
        if (selectedUserID) {
          // Make an AJAX request to fetch the filtered rental history data
          $.ajax({
            url: `/RentalHistoryByUser?user_id=${selectedUserID}`,
            method: 'GET',
            success: function(response) {
              rentalHistory = response.rentalHistory;
              console.log(rentalHistory);

              // Update the rental history table with the filtered data
              if (isOnlyActiveVisible) {
                const activeRentals = rentalHistory.filter(rental => rental.status === 'active');
                updateRentalHistoryTable(activeRentals);
              } else {
                updateRentalHistoryTable(rentalHistory);
              }
              // Enable the "Show Only Active" button
              showOnlyActiveBtn.disabled = false;
            },
            error: function(error) {
              console.error('Error fetching rental history:', error);
            }
          });
        } else {
          console.log('No user selected');
          // Clear the rental history table
          rentalHistory = [];
          updateRentalHistoryTable([]);
            // Disable the "Show Only Active" button
    showOnlyActiveBtn.disabled = true;
        }
      });

      // Function to update the rental history table
      function updateRentalHistoryTable(rentalHistory) {
        const tableBody = rentalHistoryTable.querySelector('tbody');

        tableBody.innerHTML = ''; // Clear existing table data

        // Iterate over the rental history data and create table rows
        rentalHistory.forEach(rental => {
          const takeDate = new Date(rental.takeDate);
          takeDate.setDate(takeDate.getDate() + 7);
          const returnDate = takeDate.toISOString().split('T')[0]; // Convert to YYYY-MM-DD format
          const row = document.createElement('tr');
          row.innerHTML = `
            <th scope="row">${rental.rentID}</th>
            <td>${rental.bookTitle}</td>
            <td>${rental.authorName}</td>
            <td>${rental.takeDate}</td>
            <td>${returnDate}</td>
            <td>${rental.status}</td>
            <td><button class="btn InTableBtn Returned" type="button" data-rentid="${rental.rentID}" style="display: none;">Επιστροφή</button></td>
          `;

          tableBody.appendChild(row);
        });
      }

      // Add event listener to the search bar input
      $('#Searchbar').on('input', function() {
        const searchValue = $(this).val().toLowerCase();

        // Filter the users array based on the search value
        const filteredUsers = users.filter(user =>
          user.firstName.toLowerCase().includes(searchValue) ||
          user.lastName.toLowerCase().includes(searchValue) ||
          String(user.userID).toLowerCase().includes(searchValue)
        );

        // Generate the HTML for the dropdown menu
        const dropdownMenu = $('#SearchDropdown');
        dropdownMenu.empty(); // Clear existing dropdown items

        // Populate the dropdown menu with the filtered users
        filteredUsers.forEach(user => {
          const dropdownItem = $('<a class="dropdown-item" href="#"></a>');
          dropdownItem.text(`${user.firstName} ${user.lastName}, ${user.userID}`);

          // Add event listener to populate the search bar with the selected value
          dropdownItem.on('click', function() {
            $('#Searchbar').val($(this).text());
          });

          dropdownMenu.append(dropdownItem);
        });

        // Show or hide the dropdown menu based on the number of filtered users
        dropdownMenu.toggle(filteredUsers.length > 0);
      });

      // Hide the dropdown menu when clicking outside
      $(document).on('click', function(event) {
        const dropdownMenu = $('#SearchDropdown');
        if (!dropdownMenu.is(event.target) && dropdownMenu.has(event.target).length === 0) {
          dropdownMenu.hide();
        }
      });
      
      // Add event listener to the submit button
      $('form').on('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        const searchValue = $('#Searchbar').val().toLowerCase();
        const userIdRegex = /\b\d+\b/;
        const match = searchValue.match(userIdRegex);

        let userId = null;
        if (match) {
          userId = match[0];
        }

        if (userId) {
          // Make an AJAX request to fetch the filtered rental history data
          $.ajax({
            url: `/RentalHistoryByUser?user_id=${userId}`,
            method: 'GET',
            success: function(response) {
              rentalHistory = response.rentalHistory;
              console.log(rentalHistory);

              // Update the rental history table with the filtered data
              if (isOnlyActiveVisible) {
                const activeRentals = rentalHistory.filter(rental => rental.status === 'active');
                updateRentalHistoryTable(activeRentals);
              } else {
                updateRentalHistoryTable(rentalHistory);
              }
               // Enable the "Show Only Active" button
        showOnlyActiveBtn.disabled = false;
            },
            error: function(error) {
              console.error('Error fetching rental history:', error);
            }
          });
        } else {
          console.log('No user ID found in the search field');
          // Clear the rental history table
          rentalHistory = [];
          updateRentalHistoryTable([]);
           // Disable the "Show Only Active" button
    showOnlyActiveBtn.disabled = true;
        }
      });
      
      // Add event listener to Show Only Active button
      showOnlyActiveBtn.addEventListener('click', () => {
        if (selectedUserID) {
          isOnlyActiveVisible = !isOnlyActiveVisible;
          if (isOnlyActiveVisible) {
            const activeRentals = rentalHistory.filter(rental => rental.status === 'active');
            // Update the rental history table with the filtered data
            updateRentalHistoryTable(activeRentals);
            showOnlyActiveBtn.textContent = 'Show All';
            $('.Returned').show();
            $('#Returned').show();
          } else {
            // Update the rental history table with all data
            updateRentalHistoryTable(rentalHistory);
            showOnlyActiveBtn.textContent = 'Show Only Active';
            $('.Returned').hide();
            $('#Returned').hide();
          }
        }
      });
      
      // Add event listener to "Επιστροφή" button
      $(document).on('click', '.Returned', function() {
        const rentID = $(this).data('rentid');

        // Make an AJAX request to the server.js file to perform the INSERT query
        $.ajax({
          url: '/return',
          method: 'POST',
          data: { rent_id: rentID },
          success: function(response) {
            console.log('Return successful');
            // Perform any additional actions upon successful return
          },
          error: function(error) {
            console.error('Error returning rental:', error);
          }
        });
      });
    },
    error: function(error) {
      console.error('Error fetching users:', error);
    }
  });
});




