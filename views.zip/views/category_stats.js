$(document).ready(function () {
    const logout_button = document.getElementById('modTitle');
    logout_button.addEventListener('click', function () { window.location.href = 'home_of_admin.html'; });
});

$('form').submit(function (event) {
    event.preventDefault(); // Prevent the form from submitting and reloading the page

    const category = $('#input_category').val(); // Get the value of the input field

    // Perform the AJAX request with the input category as a query parameter
    $.ajax({
        url: '/fetchCAT',
        method: 'GET',
        data: {
            category: category || undefined, // Pass the input category as a query parameter or undefined if empty
        },
        success: function (data) {
            const rowsData = data.CATsData;
            console.log(rowsData);

            const RowContainer1 = document.querySelector('#RowContainer1');
            RowContainer1.innerHTML = '';
            for (let i = 0; i < rowsData.length; i++) {
                const row = rowsData[i];

                // Create a new row element
                const rowElement = createRowElement(row, i);

                // Append the row to the book container
                RowContainer1.appendChild(rowElement);
            }

            function createRowElement(row, i) {
                const rowElement = document.createElement('tr');
                rowElement.innerHTML = `
          <th scope="row">${i + 1}</th>
          <td>${row.author_name}</td>`;

                return rowElement;
            }
 
        },

        error: function (error) {
            console.log('Error fetching book data:', error);
        }
    });

    // Perform the AJAX request with the input category as a query parameter
    $.ajax({
        url: '/fetchTeacher',
        method: 'GET',
        data: {
            category: category || undefined, // Pass the input category as a query parameter or undefined if empty
        },
        success: function (data) {
            const rowsData = data.TeachersData;
            console.log(rowsData);

            const RowContainer2 = document.querySelector('#RowContainer2');
            RowContainer2.innerHTML = '';
            for (let i = 0; i < rowsData.length; i++) {
                const row = rowsData[i];

                // Create a new row element
                const rowElement = createRowElement(row, i);

                // Append the row to the book container
                RowContainer2.appendChild(rowElement);
            }

            function createRowElement(row, i) {
                const rowElement = document.createElement('tr');
                rowElement.innerHTML = `
          <th scope="row">${i + 1}</th>
          <td>${row.teacher_name}</td>`;

                return rowElement;
            }

        },

        error: function (error) {
            console.log('Error fetching book data:', error);
        }
    });
});