// Front-end JavaScript code
$(document).ready(function() {
    // Function to update the delays table
    
    function updateDelaysTable(delays) {
      const delaysTable = document.getElementById('delaysTable');
      const tableBody = delaysTable.querySelector('tbody');
  
      tableBody.innerHTML = ''; // Clear existing table data
  
      // Iterate over the delays data and create table rows
      delays.forEach((delay, index) => {
        const takeDate = new Date(delay.take_date);
        const returnDate = new Date(takeDate.getTime() + 7 * 24 * 60 * 60 * 1000); // Add 7 days to takeDate
        const currentDate = new Date();
        const daysPassed = Math.floor((currentDate - returnDate) / (24 * 60 * 60 * 1000));
  
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${delay.rent_id}</td>        
          <td>${delay.first_name}</td>
          <td>${delay.last_name}</td>
          <td>${delay.title}</td>
          <td>${delay.copy_id}</td>
          <td>${delay.take_date}</td>
          <td>${returnDate.toISOString().split('T')[0]}</td>
          <td>${daysPassed}</td>
          <td><button class="btn InTableBtn Returned" type="button" data-rentid="${delay.rent_id}" >Return</button></td>
        `;
  
        tableBody.appendChild(row);
      });
    }
  
    // Make an AJAX request to fetch the delays data
    $.ajax({
      url: '/delays',
      method: 'GET',
      success: function(response) {
        const delays = response.delays;
        updateDelaysTable(delays);

         // Add event listener to "Επιστροφή" button
         $(document).on('click', '.Returned', function() {
          const rentID = $(this).data('rentid');
        
          // Make an AJAX request to the server.js file to perform the INSERT query
          $.ajax({
            url: '/return',
            method: 'POST',
            data: { rent_id: rentID }, // Update the variable name to rent_id
            success: function(response) {
              console.log('Return successful');
              // Perform any additional actions upon successful return
            },
            error: function(error) {
              console.error('Error returning rental:', error);
            }
          });
        });
      },
      error: function(error) {
        console.error('Error fetching delays data:', error);
      }
    });
  });
  