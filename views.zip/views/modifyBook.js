$(document).ready(function() {
    // Retrieve the clicked book data from local storage
    const row = JSON.parse(localStorage.getItem('row'));

    // Check if the row data exists
    if (row) {
        const home_button = document.getElementById('modTitle');
        home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });

        const header1 = document.getElementById('header');
        const header = document.createElement('div');
        header.innerHTML = `<h1 style="padding-top: 30px; text-decoration: underline;
                            position: relative;
                            font-family: 'Roboto';
                            font-style: normal;
                            font-weight: 400;
                            font-size: 40px;
                            text-align: center;
                            line-height: 41px;
                            color: #000000;"> Now Editing: "${row.title}" </h1>`;
        header1.appendChild(header);

        const bookId = row.book_id;

        const update_button = document.getElementById('SaveBookDetails');
        update_button.addEventListener('click', function() {
    
            const UpdatedBookData = {
                book_id: bookId,
                title: $('#bookTitle').val(),
                publisher: $('#bookPublisher').val(),
                ISBN: $('#bookISBN').val(),
                authors: $('#bookAuthors').val(),
                pages: $('#bookPages').val(),
                description: $('#bookDesciption').val(),
                book_cover: $('#bookImg').val(),
                publish_date: $('#bookPublishdate').val(),
                categories: $('#bookCategory').val(),
                language: $('#bookLanguage').val(),
                keywords: $('#bookKeywords').val()
            };
            
            //send the form data to the server for further proccessing
            $.ajax({
                url: '/UpdateBook',
                method: 'POST',
                data: UpdatedBookData,
                success: function(response) {
                    window.location.href = 'modhome.html';
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
            
            });

        console.log(row);
    } else {
      // Book data not found in local storage
      console.log('Book data not available.');
    }
    });