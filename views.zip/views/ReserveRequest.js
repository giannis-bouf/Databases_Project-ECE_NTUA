$(document).ready(function (){
    const home_button = document.getElementById('modTitle');
    home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });

    $.ajax({
        url:'/fetchResReq',
        method: 'GET',
        success: function(data) {
          const rowsData = data.resersDetails;
          console.log(rowsData);
      
          const RowContainer = document.querySelector('#RowContainer');
          RowContainer.innerHTML = '';
            for (let i = 0; i < rowsData.length; i++) {
            const row = rowsData[i];
      
            // Create a new row element
              const rowElement = createRowElement(row, i);
              RowContainer.appendChild(rowElement);

      
            function createRowElement(row, i) {
              const rowElement = document.createElement('tr');
              rowElement.innerHTML = `
              <th scope="row">${i+1}</th>
              <td>${row.first_name}</td>
              <td>${row.last_name}</td>
              <td>${row.role}</td>
              <td>${row.title}</td>
              <td>${row.activation_date}</td>
              <td><button class="btn InTableBtn Approve" id="accept" type="button">Take-Away</button></td>
              <td><button class="btn InTableBtn Deny" id="decline" type="button" style="background:#F25A5A;">Decline</button></td>
              `;
            
              rowElement.addEventListener('click', function(event) {
                if (event.target.id === 'accept') {
                  $.ajax({
                    url:'/compRes',
                    method: 'POST',
                    data: { rent_id: row.rent_id },
                    success: function(data) {
                      window.location.href = 'modhome.html';
                    },
                    error: function(error) {
                      console.log('Error fetching book data:', error);
                    }
                    });
                }
                else if (event.target.id === 'decline') {
                    $.ajax({
                      url:'/decRes',
                      method: 'POST',
                      data: { rent_id: row.rent_id },
                      success: function(data) {
                        window.location.href = 'modhome.html';
                      },
                      error: function(error) {
                        console.log('Error fetching book data:', error);
                      }
                      });
                  }
              });
        
            return rowElement;
            }
          }
        },
        error: function(error) {
          console.log('Error fetching book data:', error);
        }
      });
    
    $('form').submit(function(event) {
        event.preventDefault(); // Prevent the form from submitting and reloading the page
        
        const name = $('#name').val(); // Get the selected author value from the dropdown
    
        // Perform the AJAX request with the input word as a query parameter
        $.ajax({
            url: '/fetchResReq',
            method: 'GET',
            data: { name: name || undefined },
            success: function(data) {
                const rowsData = data.resersDetails;
                console.log(rowsData);
            
                const RowContainer = document.querySelector('#RowContainer');
                RowContainer.innerHTML = '';
                  for (let i = 0; i < rowsData.length; i++) {
                  const row = rowsData[i];
            
                  // Create a new row element
                    const rowElement = createRowElement(row, i);
                    RowContainer.appendChild(rowElement);

            
                    function createRowElement(row, i) {
                        const rowElement = document.createElement('tr');
                        rowElement.innerHTML = `
                        <th scope="row">${i+1}</th>
                        <td>${row.first_name}</td>
                        <td>${row.last_name}</td>
                        <td>${row.role}</td>
                        <td>${row.title}</td>
                        <td>${row.activation_date}</td>
                        <td><button class="btn InTableBtn Approve" id="accept" type="button">Take-Away</button></td>
                        <td><button class="btn InTableBtn Deny" id="decline" type="button" style="background:#F25A5A;">Decline</button></td>
                        `;
                      
                        rowElement.addEventListener('click', function(event) {
                          if (event.target.id === 'accept') {
                            $.ajax({
                              url:'/compRes',
                              method: 'POST',
                              data: { rent_id: row.rent_id },
                              success: function(data) {
                                window.location.href = 'modhome.html';
                              },
                              error: function(error) {
                                console.log('Error fetching book data:', error);
                              }
                              });
                          }
                          else if (event.target.id === 'decline') {
                              $.ajax({
                                url:'/decRes',
                                method: 'POST',
                                data: { rent_id: row.rent_id },
                                success: function(data) {
                                  window.location.href = 'modhome.html';
                                },
                                error: function(error) {
                                  console.log('Error fetching book data:', error);
                                }
                                });
                            }
                        });
                  
                      return rowElement;
                      }
            }
        },
        error: function(error) {
          console.log('Error fetching book data:', error);
        }
        });
      });
  })