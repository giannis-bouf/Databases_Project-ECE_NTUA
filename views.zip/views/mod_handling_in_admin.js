$(document).ready(function (){
    const logout_button = document.getElementById('modTitle');
    logout_button.addEventListener('click', function() { window.location.href = 'home_of_admin.html'; });

    $.ajax({
        url:'/fetchMods',
        method: 'GET',
        success: function(data) {
          const rowsData = data.modsData;
          console.log(rowsData);
      
          const RowContainer = document.querySelector('#RowContainer');
          RowContainer.innerHTML = '';
            for (let i = 0; i < rowsData.length; i++) {
            const row = rowsData[i];
      
            // Create a new row element

              const rowElement = createRowElement(row, i);
              RowContainer.appendChild(rowElement);          
            // Append the row to the book container
          }
      
            function createRowElement(row, i) {
              const rowElement = document.createElement('tr');
              rowElement.innerHTML = `
              <th scope="row">${i+1}</th>
              <td>${row.mod_name}</td>
              <td>${row.email}</td>
              <td>${row.school}</td>
              <td>${row.telephone}</td>
              <td>${row.address}</td>`;

              if (row.verification === 1) {
                rowElement.innerHTML += `<td><button class="btn btn-primary" id="cancel_button" style="background: red;">Cancel</button></td>`;
                rowElement.addEventListener('click', function(event) {
                    if (event.target.id === 'cancel_button') {
                      $.ajax({
                        url:'/cancelMod',
                        method: 'POST',
                        data: { mod_id: row.mod_id },
                        success: function(data) {
                          window.location.href = 'home_of_admin.html';
                        },
                        error: function(error) {
                          console.log('Error fetching book data:', error);
                        }
                        });
                    }
                  });
              }
              else if (row.active_mods === 0) {
                rowElement.innerHTML += `<td><button class="btn btn-primary" id="cancel_button">Verify</button></td>`;
                rowElement.addEventListener('click', function(event) {
                if (event.target.id === 'cancel_button') {
                  $.ajax({
                    url:'/verMod',
                    method: 'POST',
                    data: { mod_id: row.mod_id },
                    success: function(data) {
                      window.location.href = 'home_of_admin.html';
                    },
                    error: function(error) {
                      console.log('Error fetching book data:', error);
                    }
                    });
                  }
                });
              }
            return rowElement;
            }
        },
        error: function(error) {
          console.log('Error fetching book data:', error);
        }
    });
});