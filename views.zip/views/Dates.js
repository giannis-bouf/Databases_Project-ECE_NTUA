const d = new Date();

document.getElementById("CurrentDate").innerHTML = d;


Date.prototype.addDays = function(days) {
    var date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
}

var days = 1;

function add() {
    var input = document.getElementById('txtNumber');
  days = parseInt(input.value, 10) + 1;
  input.value = days;
}
function subtrack() {
    var input = document.getElementById('txtNumber');
    days = parseInt(input.value, 10) - 1;
    
    if (days < 1) {
      days = 1;
    }
    
    input.value = days;
}

function addDays() {
    if (!isNaN(days)) {
        var currentDate = new Date();
        var futureDate = currentDate.addDays(days);
        document.getElementById("ReturnDate").innerHTML = futureDate;
      } else {
        console.log('Invalid input for days.');
      }
}



var subtrackbtn = document.getElementById('subtrackbtn');
subtrackbtn.addEventListener('click', function(){
    subtrack();
    addDays();
})

var addbtn = document.getElementById('addbtn');
addbtn.addEventListener('click', function(){
    add();
    addDays();
})