$(document).ready(function() {
  const home_button = document.getElementById('history');
  home_button.addEventListener('click', function() { window.location.href = 'UserRentalHistory.html'; });
  // Show/hide categories
  const showMoreBtn = document.getElementById('showMoreBtn');
  const hiddenCategories = document.getElementById('hiddenCategories');
  const categoryItems = document.getElementsByClassName('category-item');
  const showLessBtnContainer = document.getElementById('showLessBtnContainer');
  const showLessBtn = document.getElementById('showLessBtn');
  const showMoreAuthorsBtn = document.getElementById('showMoreAuthorsBtn');
  const hiddenAuthors = document.getElementById('hiddenAuthors');
  const FirstFiveAuthors = document.getElementById('FirstFiveAuthors');
  const FirstFiveCategories = document.getElementById('FirstFiveCategories');
  const showLessAuthorsBtnContainer = document.getElementById('showLessAuthorsBtnContainer');
  const showLessAuthorsBtn = document.getElementById('showLessAuthorsBtn');
  const authorItems = document.getElementsByClassName('author-item');
  const bookTitles = document.getElementsByClassName('card-title');
  const BookCovers = document.getElementsByClassName('card-img-top');
  const profile = document.getElementById('profile');
  profile.addEventListener('click', function() { window.location.href = 'UserProfile.html'; });

  // Hide additional categories initially
  for (let i = 5; i < categoryItems.length; i++) {
    categoryItems[i].style.display = 'none';
  }

  // Hide additional authors initially
  for (let i = 5; i < authorItems.length; i++) {
    authorItems[i].style.display = 'none';
  }

  // Display the rest of the categories when the "Show More" button is clicked
  showMoreBtn.addEventListener('click', function() {
    hiddenCategories.style.display = 'block';
    showMoreBtn.style.display = 'none';
    showLessBtnContainer.style.display = 'block';

    // Show the hidden categories
    for (let i = 5; i < categoryItems.length; i++) {
      categoryItems[i].style.display = 'block';
    }
  });

  // Display the additional authors when the "Show More" button is clicked
  showMoreAuthorsBtn.addEventListener('click', function() {
    hiddenAuthors.style.display = 'block';
    showMoreAuthorsBtn.style.display = 'none';
    showLessAuthorsBtnContainer.style.display = 'block';

    // Show the hidden authors
    for (let i = 5; i < authorItems.length; i++) {
      authorItems[i].style.display = 'block';
    }
  });

  // Hide the additional categories and the "Show Less" button when the "Show Less" button is clicked
  showLessBtn.addEventListener('click', function() {
    hiddenCategories.style.display = 'none';
    showMoreBtn.style.display = 'block';
    showLessBtnContainer.style.display = 'none';

    // Hide the additional categories
    for (let i = 5; i < categoryItems.length; i++) {
      categoryItems[i].style.display = 'none';
    }
  });

  // Hide the additional authors and the "Show Less" button when the "Show Less" button is clicked
  showLessAuthorsBtn.addEventListener('click', function() {
    hiddenAuthors.style.display = 'none';
    showMoreAuthorsBtn.style.display = 'block';
    showLessAuthorsBtnContainer.style.display = 'none';

    // Hide the additional authors
    for (let i = 5; i < authorItems.length; i++) {
      authorItems[i].style.display = 'none';
    }
  });

  // Fetch the filters
  $.ajax({
    url:'/filter',
    method: 'GET',
    success: function(data) {
      const categories = data.categories;
      const authors = data.authors;
      const books = data.books;

      // Update the first 5 category items with the fetched data
      for (let i = 0; i < 5 && i < categories.length; i++) {
        const li = document.createElement('li');
        li.classList.add('category-item');
        li.innerHTML = `
          <input type="checkbox" id="${categories[i].name}" name="category" class="regular-checkbox">
          <label for="${categories[i].name}" class="categoryName" style="margin-top: 10px;">${categories[i].name}</label>
        `;
        FirstFiveCategories.appendChild(li);
      }

      // Create additional category items for the remaining categories
      for (let i = 5; i < categories.length; i++) {
        const li = document.createElement('li');
        li.classList.add('category-item');
        li.innerHTML = `
          <input type="checkbox" id="${categories[i].name}" name="category" class="regular-checkbox">
          <label for="${categories[i].name}" class="categoryName" style="margin-top: 10px;">${categories[i].name}</label>
        `;
        hiddenCategories.appendChild(li);
      }

      // Display the "Show More" button if there are more than 5 categories
      if (categories.length > 5) {
        showMoreBtn.style.display = 'block';
      }
      

      
      // Update the first 5 author items with the fetched data
      for (let i = 0; i < 5 && i < authors.length; i++) {
        const li = document.createElement('li');
        li.classList.add('author-item');
        li.innerHTML = `
          <input type="radio" id="${authors[i].name}" name="author" class="regular-radio">
          <label for="${authors[i].name}" class="authorName" style="margin-top: 10px;font-size: 15px;">${authors[i].name}</label>
        `;
        FirstFiveAuthors.appendChild(li);
      }

      // Create additional author items for the remaining authors
      for (let i = 5; i < authors.length; i++) {
        const li = document.createElement('li');
        li.classList.add('author-item');
        li.innerHTML = `
          <input type="radio" id="${authors[i].name}" name="author" class="regular-radio">
          <label for="${authors[i].name}" class="authorName" style="margin-top: 10px;font-size: 15px;">${authors[i].name}</label>
        `;
        hiddenAuthors.appendChild(li);
      }

      
      


      // Display the "Show More" button for authors if there are more than 5 authors
      if (authors.length > 5) {
        showMoreAuthorsBtn.style.display = 'block';
      }
    },
    error: function(error) {
      console.error(error);
    }
  });
});

// AJAX request to fetch the book data from the server



$.ajax({
  url:'/fetchBooks',
  method: 'GET',
  success: function(data) {
    const books = data.booksDetails;
    console.log(books);
 
    const bookCards = document.getElementsByClassName('card');
    // Update the first 4 book items with the fetched data
 

    const bookContainer = document.querySelector('#bookListMainPage');
      for (let i = 0; i < books.length; i += 2) {
      const book1 = books[i];
      const book2 = books[i + 1];

      // Create a new row element
      const rowElement = document.createElement('div');
      rowElement.classList.add('row');

      // Create the first book card element
      if (book1.average_rating !== null) {
        const card1Element = createBookCardElement(book1);
        rowElement.appendChild(card1Element);
      }
        else {
        const card1Element = createBookCardElementWithoutRating(book1);
        rowElement.appendChild(card1Element);
      }

      // Create the second book card element
      if (book2) {
        if (book2.average_rating !== null) {
          const card2Element = createBookCardElement(book2);
          rowElement.appendChild(card2Element);
        }
        else {
          const card2Element = createBookCardElementWithoutRating(book2);
          rowElement.appendChild(card2Element);
        }
      
      }
      // Append the row to the book container
      bookContainer.appendChild(rowElement);
      }

      function createBookCardElement(book) {
        const cardElement = document.createElement('div');
        cardElement.classList.add('col-sm-6');
        cardElement.innerHTML = `
        <div class="card" id="${book.book_id}" style="width: 316px; 
        background-color: #fff;
          margin-top: 41px;
          margin-left: 60px;">
            <div class="row justify-content-center"><img src="${book.book_cover}" style="width: 159px; height: 215px; object-fit: cover;" class="card-img-top" alt="bookTitle"></div>
            <div class="card-body" style="background: rgba(255, 244, 231, 0.5);
            backdrop-filter: blur(20px);">
              <a style="text-decoration: none; color: #000000;"><h5 class="card-title" style="font-family: 'Roboto';
              font-style: italic;
              font-weight: 400;
              font-size: 23px;
              width: 293px;
              height: 70px;
              line-height: 27px;
              padding-bottom: 10px;
              display: flex;
              align-items: center;
              text-align: center;">"${book.title}", ${book.authorName}</h5></a>
               <a href="bookpage.html" style="text-decoration: none; color: #000000;"><h6 class="card-subtitle" style="font-family: 'Roboto';
              font-style: italic;
              font-weight: 400;
              font-size: 17px;
              padding-bottom: 10px;
              line-height: 20px;
              display: flex;
              align-items: center;
              text-align: right;">${book.categoryName}</h6></a>
             <span style="font-family: 'Roboto';
             font-style: italic;
             font-weight: 400;
             font-size: 12px;
             line-height: 14px;
             padding-bottom: 10px;
             display: flex;
             align-items: center;
             text-align: right;"><img src="Star 1.svg" width="20" height="20" style="margin-right: 10px;">${book.average_rating}</span>
              
             
            </div>
          </div>
  `;
  cardElement.addEventListener('click', function() {
    // Store the clicked book data in local storage
    localStorage.setItem('book', JSON.stringify(book));
    
    // Redirect to bookpage.html
    window.location.href = 'bookpage.html';
  });
  return cardElement;
  }

  function createBookCardElementWithoutRating(book) {
    const cardElement = document.createElement('div');
    cardElement.classList.add('col-sm-6');
    cardElement.innerHTML = `
    <div class="card" id="${book.book_id}" style="width: 316px; 
    background-color: #fff;
      margin-top: 41px;
      margin-left: 60px;">
        <div class="row justify-content-center"><img src="${book.book_cover}" style="width: 159px; height: 215px; object-fit: cover;" class="card-img-top" alt="bookTitle"></div>
        <div class="card-body" style="background: rgba(255, 244, 231, 0.5);
        backdrop-filter: blur(20px);">
          <a style="text-decoration: none; color: #000000;"><h5 class="card-title" style="font-family: 'Roboto';
          font-style: italic;
          font-weight: 400;
          font-size: 23px;
          width: 293px;
          height: 70px;
          line-height: 27px;
          padding-bottom: 10px;
          display: flex;
          align-items: center;
          text-align: center;">"${book.title}", ${book.authorName}</h5></a>
           <a href="bookpage.html" style="text-decoration: none; color: #000000;"><h6 class="card-subtitle" style="font-family: 'Roboto';
          font-style: italic;
          font-weight: 400;
          font-size: 17px;
          padding-bottom: 10px;
          line-height: 20px;
          display: flex;
          align-items: center;
          text-align: right;">${book.categoryName}</h6></a> 
          <span style="font-family: 'Roboto';
             font-style: italic;
             font-weight: 400;
             font-size: 12px;
             line-height: 14px;
             padding-bottom: 10px;
             display: flex;
             align-items: center;
             text-align: right;"><img src="Star 1.svg" width="20" height="20" style="margin-right: 10px;"></span>
        </div>
      </div>
`;
cardElement.addEventListener('click', function() {
// Store the clicked book data in local storage
localStorage.setItem('book', JSON.stringify(book));

// Redirect to bookpage.html
window.location.href = 'bookpage.html';
});
return cardElement;
}

},
  error: function(error) {
    console.log('Error fetching book data:', error);
  }
});

$('form').submit(function(event) {
  event.preventDefault(); // Prevent the form from submitting and reloading the page

  const word = $('#title_search').val(); // Get the value of the input field

  // Perform the AJAX request with the input word as a query parameter
  $.ajax({
    url: '/fetchBooks',
    method: 'GET',
    data: {
      word: word || undefined // Pass the input word as a query parameter or undefined if empty
    },
    success: function(data) {
      // Update the book list view with the filtered books
      const books = data.booksDetails;
      console.log(books);

      const bookContainer = document.querySelector('#bookListMainPage');
      bookContainer.innerHTML = ''; // Clear the existing book list

      for (let i = 0; i < books.length; i += 2) {
        const book1 = books[i];
        const book2 = books[i + 1];

      // Create a new row element
      const rowElement = document.createElement('div');
      rowElement.classList.add('row');

      // Create the first book card element
      const card1Element = createBookCardElement(book1);
      rowElement.appendChild(card1Element);

      // Create the second book card element
      if (book2) {
        const card2Element = createBookCardElement(book2);
        rowElement.appendChild(card2Element);
      }

      // Append the row to the book container
      bookContainer.appendChild(rowElement);
    }

    function createBookCardElement(book) {
      const cardElement = document.createElement('div');
      cardElement.classList.add('col-sm-6');
      cardElement.innerHTML = `
      <div class="card" id="${book.book_id}" style="width: 316px; 
      background-color: #fff;
        margin-top: 41px;
        margin-left: 60px;">
          <div class="row justify-content-center"><img src="${book.book_cover}" style="width: 159px; height: 215px; object-fit: cover;" class="card-img-top" alt="bookTitle"></div>
          <div class="card-body" style="background: rgba(255, 244, 231, 0.5);
          backdrop-filter: blur(20px);">
            <a style="text-decoration: none; color: #000000;"><h5 class="card-title" style="font-family: 'Roboto';
            font-style: italic;
            font-weight: 400;
            font-size: 23px;
            width: 293px;
            height: 70px;
            line-height: 27px;
            padding-bottom: 10px;
            display: flex;
            align-items: center;
            text-align: center;">"${book.title}", ${book.authorName}</h5></a>
             <a href="bookpage.html" style="text-decoration: none; color: #000000;"><h6 class="card-subtitle" style="font-family: 'Roboto';
            font-style: italic;
            font-weight: 400;
            font-size: 17px;
            padding-bottom: 10px;
            line-height: 20px;
            display: flex;
            align-items: center;
            text-align: right;">${book.categoryName}</h6></a>
           <span style="font-family: 'Roboto';
           font-style: italic;
           font-weight: 400;
           font-size: 12px;
           line-height: 14px;
           padding-bottom: 10px;
           display: flex;
           align-items: center;
           text-align: right;"><img src="Star 1.svg" width="20" height="20" style="margin-right: 10px;">${book.average_rating}</span>
            
           
          </div>
        </div>
`;
cardElement.addEventListener('click', function() {
  // Store the clicked book data in local storage
  localStorage.setItem('book', JSON.stringify(book));
  
  // Redirect to bookpage.html
  window.location.href = 'bookpage.html';
});
return cardElement;
}
      // Rest of your code to update the book list view
    },
    error: function(error) {
      console.log('Error fetching book data:', error);
    }
  });
});

$('#authorsApplybtn').click(function() {
  const selectedAuthor = $('input[name="author"]:checked').attr('id'); // Get the ID of the selected author radio button

  // Perform the AJAX request with the input word as a query parameter
  $.ajax({
    url: '/fetchBooks',
    method: 'GET',
    data: {
      author: selectedAuthor || undefined // Pass the input word as a query parameter or undefined if empty
    },
    success: function(data) {
      // Update the book list view with the filtered books
      const books = data.booksDetails;
      console.log(books);

      const bookContainer = document.querySelector('#bookListMainPage');
      bookContainer.innerHTML = ''; // Clear the existing book list

      for (let i = 0; i < books.length; i += 2) {
        const book1 = books[i];
        const book2 = books[i + 1];

      // Create a new row element
      const rowElement = document.createElement('div');
      rowElement.classList.add('row');

      // Create the first book card element
      const card1Element = createBookCardElement(book1);
      rowElement.appendChild(card1Element);

      // Create the second book card element
      if (book2) {
        const card2Element = createBookCardElement(book2);
        rowElement.appendChild(card2Element);
      }

      // Append the row to the book container
      bookContainer.appendChild(rowElement);
    }

    function createBookCardElement(book) {
      const cardElement = document.createElement('div');
      cardElement.classList.add('col-sm-6');
      cardElement.innerHTML = `
      <div class="card" id="${book.book_id}" style="width: 316px; 
      background-color: #fff;
        margin-top: 41px;
        margin-left: 60px;">
          <div class="row justify-content-center"><img src="${book.book_cover}" style="width: 159px; height: 215px; object-fit: cover;" class="card-img-top" alt="bookTitle"></div>
          <div class="card-body" style="background: rgba(255, 244, 231, 0.5);
          backdrop-filter: blur(20px);">
            <a style="text-decoration: none; color: #000000;"><h5 class="card-title" style="font-family: 'Roboto';
            font-style: italic;
            font-weight: 400;
            font-size: 23px;
            width: 293px;
            height: 70px;
            line-height: 27px;
            padding-bottom: 10px;
            display: flex;
            align-items: center;
            text-align: center;">"${book.title}", ${book.authorName}</h5></a>
             <a href="bookpage.html" style="text-decoration: none; color: #000000;"><h6 class="card-subtitle" style="font-family: 'Roboto';
            font-style: italic;
            font-weight: 400;
            font-size: 17px;
            padding-bottom: 10px;
            line-height: 20px;
            display: flex;
            align-items: center;
            text-align: right;">${book.categoryName}</h6></a>
           <span style="font-family: 'Roboto';
           font-style: italic;
           font-weight: 400;
           font-size: 12px;
           line-height: 14px;
           padding-bottom: 10px;
           display: flex;
           align-items: center;
           text-align: right;"><img src="Star 1.svg" width="20" height="20" style="margin-right: 10px;">${book.average_rating}</span>
            
           
          </div>
        </div>
`;
cardElement.addEventListener('click', function() {
  // Store the clicked book data in local storage
  localStorage.setItem('book', JSON.stringify(book));
  
  // Redirect to bookpage.html
  window.location.href = 'bookpage.html';
});
return cardElement;
}
      // Rest of your code to update the book list view
    },
    error: function(error) {
      console.log('Error fetching book data:', error);
    }
  });
});

$('#categoriesApplybtn').click(function() {
  const selectedCategories = $('input[name="category"]:checked')
    .map(function() {
      return this.id; // Get the ID of each selected category checkbox
    })
    .get();

  // Perform the AJAX request with the input word as a query parameter
  $.ajax({
    url: '/fetchBooks',
    method: 'GET',
    data: {
      // Pass the selected categories as a query parameter or undefined if none selected
      categories: selectedCategories.length > 0 ? selectedCategories : undefined 
    },
    success: function(data) {
      // Update the book list view with the filtered books
      const books = data.booksDetails;
      console.log(books);

      const bookContainer = document.querySelector('#bookListMainPage');
      bookContainer.innerHTML = ''; // Clear the existing book list

      for (let i = 0; i < books.length; i += 2) {
        const book1 = books[i];
        const book2 = books[i + 1];

      // Create a new row element
      const rowElement = document.createElement('div');
      rowElement.classList.add('row');

      // Create the first book card element
      const card1Element = createBookCardElement(book1);
      rowElement.appendChild(card1Element);

      // Create the second book card element
      if (book2) {
        const card2Element = createBookCardElement(book2);
        rowElement.appendChild(card2Element);
      }

      // Append the row to the book container
      bookContainer.appendChild(rowElement);
    }

    function createBookCardElement(book) {
      const cardElement = document.createElement('div');
      cardElement.classList.add('col-sm-6');
      cardElement.innerHTML = `
      <div class="card" id="${book.book_id}" style="width: 316px; 
      background-color: #fff;
        margin-top: 41px;
        margin-left: 60px;">
          <div class="row justify-content-center"><img src="${book.book_cover}" style="width: 159px; height: 215px; object-fit: cover;" class="card-img-top" alt="bookTitle"></div>
          <div class="card-body" style="background: rgba(255, 244, 231, 0.5);
          backdrop-filter: blur(20px);">
            <a style="text-decoration: none; color: #000000;"><h5 class="card-title" style="font-family: 'Roboto';
            font-style: italic;
            font-weight: 400;
            font-size: 23px;
            width: 293px;
            height: 70px;
            line-height: 27px;
            padding-bottom: 10px;
            display: flex;
            align-items: center;
            text-align: center;">"${book.title}", ${book.authorName}</h5></a>
             <a href="bookpage.html" style="text-decoration: none; color: #000000;"><h6 class="card-subtitle" style="font-family: 'Roboto';
            font-style: italic;
            font-weight: 400;
            font-size: 17px;
            padding-bottom: 10px;
            line-height: 20px;
            display: flex;
            align-items: center;
            text-align: right;">${book.categoryName}</h6></a>
           <span style="font-family: 'Roboto';
           font-style: italic;
           font-weight: 400;
           font-size: 12px;
           line-height: 14px;
           padding-bottom: 10px;
           display: flex;
           align-items: center;
           text-align: right;"><img src="Star 1.svg" width="20" height="20" style="margin-right: 10px;">${book.average_rating}</span>
            
           
          </div>
        </div>
`;
cardElement.addEventListener('click', function() {
  // Store the clicked book data in local storage
  localStorage.setItem('book', JSON.stringify(book));
  
  // Redirect to bookpage.html
  window.location.href = 'bookpage.html';
});
return cardElement;
}
      // Rest of your code to update the book list view
    },
    error: function(error) {
      console.log('Error fetching book data:', error);
    }
  });
});