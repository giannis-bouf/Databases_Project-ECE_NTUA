$(document).ready(function() {
// Retrieve the clicked book data from local storage
const book = JSON.parse(localStorage.getItem('book'));

// Check if the book data exists
if (book) {
  const home_button = document.getElementById('history');
  home_button.addEventListener('click', function() { window.location.href = 'UserRentalHistory.html'; });
  const profile = document.getElementById('profile');
  profile.addEventListener('click', function() { window.location.href = 'UserProfile.html'; });

  // Access the book details
  const bookId = book.book_id;
  const bookTitle = book.title;
  const authorName = book.authorName;
  const cover = book.book_cover;
  const description = book.description;
  const average_rating = book.average_rating;
  const keywords = book.keyWord;
  const pages = book.pages;
  const publisher = book.publisher;
  const language = book.language;
  const category = book.categoryName;

  const title_name = document.getElementById('title_and_name');
  title_name.textContent = book.title + ' - ' + authorName.join(', ');

  const cover_id = document.getElementById('Cover');
  cover_id.src = cover;

  const desc_id = document.getElementById('desc');
  desc_id.textContent = description;

  const rat_id = document.getElementById('rating');
  rat_id.textContent = average_rating ? average_rating + " of 5": '';

  const line_id = document.getElementById('line');
  line_id.textContent = 'Categories: ' + category.join(', ') + ' - Key words: ' + keywords.join(', ');

  const header_id = document.getElementById('header');
  header_id.textContent = '| ' + bookTitle + ' | ' + authorName.join(', ') + ' | Pages: ' + pages + ' | Publisher: ' + publisher + ' | ' + language + ' |';
  
  if (average_rating !== null) {
  // Get the first digit of the rating
  var firstDigit = parseInt(average_rating.toString()[0]);
  var secDigit = parseInt(average_rating.toString()[2]);
  if (secDigit>4) firstDigit++;

  // Generate star buttons
  var avg_stars = '';
  for (let u = 0; u < 5; u++) {
    if (u < firstDigit) {
      avg_stars += '<span class="star">&#9733;</span> ';
    } else {
      avg_stars += '<span class="star">&#9734;</span> ';
    }
  }

  
  }
  else {
    var avg_stars = '';
    for (let u = 0; u < 5; u++) {
      avg_stars += '<span class="star">&#9734;</span> ';
    }
  }
    
  // Append the generated stars to the star_rating element
  $('#avg_stars').html(avg_stars);
  
  

  // Now you can use the book data in your bookpage.js file
  // For example, you can display the book details on the book page
  console.log('Book ID:', bookId);
  console.log('Book Title:', bookTitle);
  console.log('Author Name:', authorName);
  console.log('Description:', description );
  console.log('Rating:', average_rating );

  $.ajax({
    url: '/fetchRatings',
    method: 'GET',
    data: { bookId: bookId },
    success: function(data) {
      const comments = data.comments;
      const ratings = data.ratings;
      const usernames = data.usernames;
      const rating_ids = data.rating_ids;

      console.log('Comments:', comments);
      console.log('Ratings:', ratings);
      console.log('Usernames:', usernames);
      console.log('Ratings:', rating_ids);
      
      const MoreRatings = document.getElementById('MoreRatings');
      
      for (let i = 0; i < ratings.length; i++) {
        const div = document.createElement('div');
        div.classList.add('form-group', 'AllRatings');
        div.style.marginTop = '18px';
        div.style.marginTop = '20px';
        
        if (comments[i] !== null) {
          div.innerHTML = `
          <label for="Addyourcomment" style="font-family: 'Roboto';
                      font-style: italic;
                      font-weight: 300;
                      font-size: 25px;
                      line-height: 29px;
                      margin-bottom: 5px;
                      border-bottom: 1px solid #000000;
                      padding-bottom: 3px;
                      ">${usernames[i]}</label>
                    
                      <div class="row" style="border-bottom: 1px solid #000000; padding-bottom: 20px;">
                        <div class="col-sm-4">
                          <div class="row justify-content-center">
                      <div id="${rating_ids[i]}" class="star_rating" style="width: 220px; display: flex; align-items: center;">
                        <span class="star">&#9734;</span> 
                        <span class="star">&#9734;</span>
                        <span class="star">&#9734;</span>
                        <span class="star">&#9734;</span>
                        <span class="star">&#9734;</span>
                      </div></div>
                      <p class="current_rating" style="padding-top: 15px; padding-left: 0px; text-align: center;">${ratings[i]} of 5</p></div>
                                             
                       <textarea class="form-control col-sm-8" id="Addyourcomment" rows="3" style="width:545px;                        
                       background: rgba(255, 255, 255, 0.8);
                       border-radius: 20px;
                       font-family: 'Roboto';
                      font-style: italic;
                      font-weight: 400;
                      font-size: 15px;
                      line-height: 18px;" placeholder="${comments[i]}" readonly></textarea></div>
        `;
      }
        else {
          div.innerHTML = `
          <div class="row" style="border-bottom: 1px solid #000000; padding-bottom: 20px;">
            <div class="col-sm-4">
              <label for="Addyourcomment" style="font-family: 'Roboto';
              font-style: italic;
              font-weight: 300;
              font-size: 25px;
              line-height: 29px;
              margin-bottom: 5px;
              border-bottom: 1px solid #000000;
              padding-bottom: 3px;">${usernames[i]}</label>
            </div>
            <div class="col-sm-8">
              <div class="row justify-content-start">
                <div id="${rating_ids[i]}" class="star_rating" style="width: 220px; display: flex; align-items: center;">
                  <span class="star">&#9734;</span> 
                  <span class="star">&#9734;</span>
                  <span class="star">&#9734;</span>
                  <span class="star">&#9734;</span>
                  <span class="star">&#9734;</span>
                </div>
                <p class="current_rating" style="padding-top: 15px; padding-left: 10px;">${ratings[i]} of 5</p>
              </div>
            </div>
          </div>
        `;
        }
        
        MoreRatings.appendChild(div);
      
      }

      for (let i=0; i<rating_ids.length; i++) {
        const current_rating = document.getElementById(rating_ids[i]);
        
        // Get the first digit of the rating
        var firstDigit = parseInt(ratings[i].toString()[0]);
        var secDigit = parseInt(ratings[i].toString()[2]);
        if (secDigit>4) firstDigit++;
  
        // Generate star buttons
        var stars = '';
        for (let u = 0; u < 5; u++) {
          if (u < firstDigit) {
            stars += '<span class="star">&#9733;</span> ';
          } else {
            stars += '<span class="star">&#9734;</span> ';
          }
        }
  
        // Append the generated stars to the star_rating element
        $(current_rating).html(stars);}
    },
    error: function(error) {
      console.log('Error fetching available copies:', error);
    }
  });

  $.ajax({
    url: '/fetchAvailableCopies',
    method: 'GET',
    data: { bookId: bookId },
    success: function(data) {
      const availableCopies = data.availableCopies;
      console.log('Available Copies:', availableCopies);

      if (availableCopies == 0) {
        the_button.style.background = '#FFFF00';
        the_button.textContent = 'Reserve';
      }
    },
    error: function(error) {
      console.log('Error fetching available copies:', error);
    }
  });
  
  const the_button = document.getElementById('rental_submit');
  the_button.addEventListener('click', function() {
    // Handle button click event
    $.ajax({
      url: '/insertRental',
      method: 'POST',
      data: { bookId: bookId },
      success: function(response) {
        console.log('Reservation inserted successfully:', response);
        // Redirect to booklist.html
        window.location.href = 'bookslist.html';
      },
      error: function(error) {
        console.log('Error inserting reservation:', error);
      }
    });
  });

  const logout_button = document.getElementById('logout_button');
  logout_button.addEventListener('click', function() {
    // Handle button click event
    window.location.href = 'index.html';
  });

  let selectedRating = 0;

  const star1 = document.getElementById('star1');
  const star2 = document.getElementById('star2');
  const star3 = document.getElementById('star3');
  const star4 = document.getElementById('star4');
  const star5 = document.getElementById('star5');

  star1.addEventListener('click', function() { selectedRating = 1; });
  star2.addEventListener('click', function() { selectedRating = 2; });
  star3.addEventListener('click', function() { selectedRating = 3; });
  star4.addEventListener('click', function() { selectedRating = 4; });
  star5.addEventListener('click', function() { selectedRating = 5; });

  const submit_button = document.getElementById('submit_button');
  submit_button.addEventListener('click', function() {
    const comment = document.getElementById('Addyourcomment').value;
    const rating = selectedRating;

    console.log("Rating:", rating);
    console.log("Comment:", comment);
    $.ajax({
      url: '/insertRating',
      method: 'POST',
      data: { 
        bookId: bookId,
        rating: rating,
        comment: comment || null 
      },
      success: function(response) {
        console.log('Reservation inserted successfully:', response);
        // Redirect to booklist.html
        window.location.href = 'bookslist.html';
      },
      error: function(error) {
        console.log('Error inserting reservation:', error);
      }
    });
  });

} else {
  // Book data not found in local storage
  console.log('Book data not available.');
}
});


