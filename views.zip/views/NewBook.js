$(document).ready(function (){
    const home_button = document.getElementById('modTitle');
    home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });
    
    const SaveNewBook = document.getElementById('SaveNewBook');
    SaveNewBook.addEventListener('click', function() {
    
    const NewBookData = {
        title: $('#bookTitle').val(),
        publisher: $('#bookPublisher').val(),
        ISBN: $('#bookISBN').val(),
        authors: $('#bookAuthors').val(),
        pages: $('#bookPages').val(),
        description: $('#bookDesciption').val(),
        copies: $('#bookCopies').val(),
        book_cover: $('#bookImg').val(),
        publish_date: $('#bookPublishdate').val(),
        category: $('#bookCategory').val(),
        language: $('#bookLanguage').val(),
        key_words: $('#bookKeywords').val()
    };
    
    //send the form data to the server for further proccessing
    $.ajax({
        url: '/CreateNewBook',
        method: 'POST',
        data: NewBookData,
        success: function(response) {
            window.location.href = 'modhome.html';
        },
        error: function (xhr, status, error) {
            console.error(xhr.responseText);
        }
    });
    
    });
});