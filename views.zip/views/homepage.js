$.ajax({
    url:'/home',
    method: 'GET',
    success: function(data) {
        // extract username, schoolName and role from the data
        const { username, schoolName, role} = data;
        //update html element
        console.log(data);
        $('#homeTitle').text(`School Library || ${schoolName} `);
    }, 
    error: function (error) {
        console.error(error);
       
    }
});

const profile = document.getElementById('profile');
profile.addEventListener('click', function() { window.location.href = 'UserProfile.html'; });

const RentalHistoryRect = document.getElementById('RentalHistoryRect');
RentalHistoryRect.addEventListener('click', function() { window.location.href = 'UserRentalHistory.html'; });