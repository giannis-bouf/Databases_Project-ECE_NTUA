$(document).ready(function (){
    const home_button = document.getElementById('modTitle');
    home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });

    $.ajax({
        url:'/fetchRenReq',
        method: 'GET',
        success: function(data) {
          const rowsData = data.reqsDetails;
          console.log(rowsData);
      
          const RowContainer = document.querySelector('#RowContainer');
          RowContainer.innerHTML = '';
            for (let i = 0; i < rowsData.length; i++) {
            const row = rowsData[i];
      
            // Create a new row element
            if(row.av_copies > 0) {
              const rowElement = createRowElementRent(row, i);
              RowContainer.appendChild(rowElement);
            }
            else {
              const rowElement = createRowElementRes(row, i);
              RowContainer.appendChild(rowElement);
            }
          }
      
            function createRowElementRent(row, i) {
              const rowElement = document.createElement('tr');
              rowElement.innerHTML = `
              <th scope="row">${i+1}</th>
              <td>${row.first_name}</td>
              <td>${row.last_name}</td>
              <td>${row.role}</td>
              <td>${row.title}</td>
              <td><button class="btn InTableBtn Approve" id="accept" type="button">Rent</button></td>
              <td><button class="btn InTableBtn Deny" id="decline" type="button" style="background:#F25A5A;">Decline</button></td>
              `;
            
              rowElement.addEventListener('click', function(event) {
                if (event.target.id === 'accept') {
                  $.ajax({
                    url:'/accRen',
                    method: 'POST',
                    data: { request_id: row.request_id },
                    success: function(data) {
                      window.location.href = 'modhome.html';
                    },
                    error: function(error) {
                      console.log('Error fetching book data:', error);
                    }
                    });
                }
                else if (event.target.id === 'decline') {
                    $.ajax({
                      url:'/decRen',
                      method: 'POST',
                      data: { request_id: row.request_id },
                      success: function(data) {
                        window.location.href = 'modhome.html';
                      },
                      error: function(error) {
                        console.log('Error fetching book data:', error);
                      }
                      });
                  }
              });
        
            return rowElement;
        }
        
        function createRowElementRes(row, i) {
          const rowElement = document.createElement('tr');
          rowElement.innerHTML = `
          <th scope="row">${i+1}</th>
              <td>${row.first_name}</td>
              <td>${row.last_name}</td>
              <td>${row.role}</td>
              <td>${row.title}</td>
              <td><button class="btn InTableBtn Approve" id="accept" style="background: yellow;" type="button">Reserve</button></td>
              <td><button class="btn InTableBtn Deny" id="decline" type="button" style="background:#F25A5A;">Decline</button></td>`;
        
              rowElement.addEventListener('click', function(event) {
                if (event.target.id === 'accept') {
                  $.ajax({
                    url:'/accRen',
                    method: 'POST',
                    data: { request_id: row.request_id },
                    success: function(data) {
                      window.location.href = 'modhome.html';
                    },
                    error: function(error) {
                      console.log('Error fetching book data:', error);
                    }
                    });
                }
                else if (event.target.id === 'decline') {
                    $.ajax({
                      url:'/decRen',
                      method: 'POST',
                      data: { request_id: row.request_id },
                      success: function(data) {
                        window.location.href = 'modhome.html';
                      },
                      error: function(error) {
                        console.log('Error fetching book data:', error);
                      }
                      });
                  }
              });
    
        return rowElement;
    }
      },
        error: function(error) {
          console.log('Error fetching book data:', error);
        }
      });
    
    $('form').submit(function(event) {
        event.preventDefault(); // Prevent the form from submitting and reloading the page
        
        const name = $('#name').val();
        const title = $('#title').val();
    
        // Perform the AJAX request with the input word as a query parameter
        $.ajax({
            url: '/fetchRenReq',
            method: 'GET',
            data: { name: name || undefined, 
                    title: title || undefined },
            success: function(data) {
                const rowsData = data.reqsDetails;
                console.log(rowsData);
            
                const RowContainer = document.querySelector('#RowContainer');
                RowContainer.innerHTML = '';
                  for (let i = 0; i < rowsData.length; i++) {
                  const row = rowsData[i];
            
                  // Create a new row element
                  if(row.av_copies > 0) {
                    const rowElement = createRowElementRent(row, i);
                    RowContainer.appendChild(rowElement);
                  }
                  else {
                    const rowElement = createRowElementRes(row, i);
                    RowContainer.appendChild(rowElement);
                  }
                }
            
                  function createRowElementRent(row, i) {
                    const rowElement = document.createElement('tr');
                    rowElement.innerHTML = `
                    <th scope="row">${i+1}</th>
                    <td>${row.first_name}</td>
                    <td>${row.last_name}</td>
                    <td>${row.role}</td>
                    <td>${row.title}</td>
                    <td><button class="btn InTableBtn Approve" id="accept" type="button">Rent</button></td>
                    <td><button class="btn InTableBtn Deny" id="decline" type="button" style="background:#F25A5A;">Decline</button></td>
                    `;
                  
                    rowElement.addEventListener('click', function(event) {
                      if (event.target.id === 'accept') {
                        $.ajax({
                          url:'/accRen',
                          method: 'POST',
                          data: { request_id: row.request_id },
                          success: function(data) {
                            window.location.href = 'modhome.html';
                          },
                          error: function(error) {
                            console.log('Error fetching book data:', error);
                          }
                          });
                      }
                      else if (event.target.id === 'decline') {
                          $.ajax({
                            url:'/decRen',
                            method: 'POST',
                            data: { request_id: row.request_id },
                            success: function(data) {
                              window.location.href = 'modhome.html';
                            },
                            error: function(error) {
                              console.log('Error fetching book data:', error);
                            }
                            });
                        }
                    });
              
                  return rowElement;
              }
              
              function createRowElementRes(row, i) {
                const rowElement = document.createElement('tr');
                rowElement.innerHTML = `
                <th scope="row">${i+1}</th>
                    <td>${row.first_name}</td>
                    <td>${row.last_name}</td>
                    <td>${row.role}</td>
                    <td>${row.title}</td>
                    <td><button class="btn InTableBtn Approve" id="accept" style="background: yellow;" type="button">Reserve</button></td>
                    <td><button class="btn InTableBtn Deny" id="decline" type="button" style="background:#F25A5A;">Decline</button></td>`;
              
                    rowElement.addEventListener('click', function(event) {
                      if (event.target.id === 'accept') {
                        $.ajax({
                          url:'/accRen',
                          method: 'POST',
                          data: { request_id: row.request_id },
                          success: function(data) {
                            window.location.href = 'modhome.html';
                          },
                          error: function(error) {
                            console.log('Error fetching book data:', error);
                          }
                          });
                      }
                      else if (event.target.id === 'decline') {
                          $.ajax({
                            url:'/decRen',
                            method: 'POST',
                            data: { request_id: row.request_id },
                            success: function(data) {
                              window.location.href = 'modhome.html';
                            },
                            error: function(error) {
                              console.log('Error fetching book data:', error);
                            }
                            });
                        }
                    });
          
              return rowElement;
          }
            },
        error: function(error) {
          console.log('Error fetching book data:', error);
        }
        });
      });
  })