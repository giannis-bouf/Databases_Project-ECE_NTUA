// User List Page
if (window.location.pathname === '/ReserveHistoryByUser.html') {
    $(document).ready(function() {
      let selectedUserID = null;
      let rentalHistory = []; // Variable to store the fetched rental history data
      let isOnlyActiveVisible = false; // Variable to track if only active rentals are visible
  
      // AJAX request to fetch user data
      $.ajax({
        url: '/ReserveHistory',
        method: 'GET',
        success: function(response) {
          const users = response.users;
          console.log(users);
          const usersList = document.getElementById('UsersList');
          const userListHTML = users.map(user => {
            return `
              <li class="User-item" style="font-family: 'Roboto';
              font-style: normal;
              font-weight: 600;
              font-size: 20px;">
                <input type="radio" id="user_${user.userID}" name="user" class="regular-radio">
                <label for="user_${user.userID}" class="userName"><br>${user.firstName} ${user.lastName}, ${user.username}</label>
              </li>
            `;
          }).join('');
  
          usersList.innerHTML = `<ul style="list-style: none;">${userListHTML}</ul>`;
  
          // Add event listener to user selection
          $('input[name="user"]').on('change', function() {
            selectedUserID = this.id.split('_')[1];
          });
  
          const userApplyBtn = document.getElementById('UserApplybtn');
          const rentalHistoryTable = document.getElementById('rentalTable');
          
          // Add event listener to the Apply button
          userApplyBtn.addEventListener('click', () => {
            if (selectedUserID) {
              // Make an AJAX request to fetch the filtered rental history data
              $.ajax({
                url: `/ReserveHistoryByUser?user_id=${selectedUserID}`,
                method: 'GET',
                success: function(response) {
                  rentalHistory = response.rentalHistory;
                  console.log(rentalHistory);
  
                  // Update the rental history table with the filtered data
                  if (isOnlyActiveVisible) {
                    const activeRentals = rentalHistory.filter(rental => rental.status === 'active');
                    updateRentalHistoryTable(activeRentals);
                  } else {
                    updateRentalHistoryTable(rentalHistory);
                  }
                  
                },
                error: function(error) {
                  console.error('Error fetching reserve history:', error);
                }
              });
            } else {
              console.log('No user selected');
              // Clear the rental history table
              rentalHistory = [];
              updateRentalHistoryTable([]);
                
            }
          });
  
          // Function to update the rental history table
          function updateRentalHistoryTable(rentalHistory) {
            const tableBody = rentalHistoryTable.querySelector('tbody');
  
            tableBody.innerHTML = ''; // Clear existing table data
  
            // Iterate over the rental history data and create table rows
            rentalHistory.forEach(reserve => {
              const row = document.createElement('tr');
              row.innerHTML = `
                <th scope="row">${reserve.rentID}</th>
                <td>${reserve.bookTitle}</td>
                <td>${reserve.authorName}</td>
                <td>${reserve.reservationDate}</td>
                <td>${reserve.status}</td>
              `;
  
              tableBody.appendChild(row);
            });
          }
  
          // Add event listener to the search bar input
          $('#Searchbar').on('input', function() {
            const searchValue = $(this).val().toLowerCase();
  
            // Filter the users array based on the search value
            const filteredUsers = users.filter(user =>
              user.firstName.toLowerCase().includes(searchValue) ||
              user.lastName.toLowerCase().includes(searchValue) ||
              String(user.userID).toLowerCase().includes(searchValue)
            );
  
            // Generate the HTML for the dropdown menu
            const dropdownMenu = $('#SearchDropdown');
            dropdownMenu.empty(); // Clear existing dropdown items
  
            // Populate the dropdown menu with the filtered users
            filteredUsers.forEach(user => {
              const dropdownItem = $('<a class="dropdown-item" href="#"></a>');
              dropdownItem.text(`${user.firstName} ${user.lastName}, ${user.userID}`);
  
              // Add event listener to populate the search bar with the selected value
              dropdownItem.on('click', function() {
                $('#Searchbar').val($(this).text());
              });
  
              dropdownMenu.append(dropdownItem);
            });
  
            // Show or hide the dropdown menu based on the number of filtered users
            dropdownMenu.toggle(filteredUsers.length > 0);
          });
  
          // Hide the dropdown menu when clicking outside
          $(document).on('click', function(event) {
            const dropdownMenu = $('#SearchDropdown');
            if (!dropdownMenu.is(event.target) && dropdownMenu.has(event.target).length === 0) {
              dropdownMenu.hide();
            }
          });
          
          // Add event listener to the submit button
          $('form').on('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
  
            const searchValue = $('#Searchbar').val().toLowerCase();
            const userIdRegex = /\b\d+\b/;
            const match = searchValue.match(userIdRegex);
  
            let userId = null;
            if (match) {
              userId = match[0];
            }
  
            if (userId) {
              // Make an AJAX request to fetch the filtered rental history data
              $.ajax({
                url: `/ReserveHistoryByUser?user_id=${userId}`,
                method: 'GET',
                success: function(response) {
                  rentalHistory = response.rentalHistory;
                  console.log(rentalHistory);

                    updateRentalHistoryTable(rentalHistory);
                  
                  
                },
                error: function(error) {
                  console.error('Error fetching rental history:', error);
                }
              });
            } else {
              console.log('No user ID found in the search field');
              // Clear the rental history table
              rentalHistory = [];
              updateRentalHistoryTable([]);
              
            }
          });
          
        },
        error: function(error) {
          console.error('Error fetching users:', error);
        }
      });
    });
  }
  
  
  
  // Book List Page
  if (window.location.pathname === '/ReserveHistoryByBook.html') {
    $(document).ready(function() {
        let selecteBookID = null;
        let rentalHistory = [];
       
      // AJAX request to fetch book data
      $.ajax({
        url: '/ReserveHistory',
        method: 'GET',
        success: function(response) {
            const books = response.books;
            console.log(books);
            const booksList = document.getElementById('BooksList');
            const bookListHTML = books.map(book => {
              return `
                <li class="Book-item" style="font-family: 'Roboto';
                font-style: normal;
                font-weight: 600;
                font-size: 20px;">
                  <input type="radio" id="book_${book.bookID}" name="book" class="regular-radio">
                  <label for="book_${book.bookID}" class="bookName"><br>${book.bookTitle}, ${book.authorName}</label>
                </li>
              `;
            }).join('');
      
            booksList.innerHTML = `<ul style="list-style: none;">${bookListHTML}</ul>`;

             // Add event listener to user selection
          $('input[name="book"]').on('change', function() {
            selecteBookID = this.id.split('_')[1];
          });

          const bookApplyBtn = document.getElementById('UserApplybtn');
          const rentalHistoryTable = document.getElementById('rentalTable');
            // Add event listener to the Apply button
            bookApplyBtn.addEventListener('click', () => {
            if (selecteBookID) {
              // Make an AJAX request to fetch the filtered rental history data
              $.ajax({
                url: `/ReservelHistoryByUser?user_id=${selecteBookID}`,
                method: 'GET',
                success: function(response) {
                  rentalHistory = response.rentalHistory;
                  console.log(rentalHistory);
                    updateRentalHistoryTable(rentalHistory);
                
                },
                error: function(error) {
                  console.error('Error fetching rental history:', error);
                }
              });
            } else {
              console.log('No book selected');
              // Clear the rental history table
              rentalHistory = [];
              updateRentalHistoryTable([]);
               
            }
          });

           // Function to update the rental history table
           function updateRentalHistoryTable(rentalHistory) {
            const tableBody = rentalHistoryTable.querySelector('tbody');
  
            tableBody.innerHTML = ''; // Clear existing table data
  
            // Iterate over the rental history data and create table rows
            rentalHistory.forEach(reserve => {
              const row = document.createElement('tr');
              row.innerHTML = `
                <th scope="row">${reserve.rentID}</th>
                <td>${reserve.firstName}</td>
                <td>${reserve.lastName}</td>
                <td>${reserve.reservationDate}</td>
                <td>${reserve.status}</td>
              `;
  
              tableBody.appendChild(row);
            });
          }

          // Add event listener to the search bar input
          $('#Searchbar').on('input', function() {
            const searchValue = $(this).val().toLowerCase();
  
            // Filter the users array based on the search value
            const filteredBooks = books.filter(book =>
              book.bookTitle.toLowerCase().includes(searchValue) ||
              String(book.bookID).toLowerCase().includes(searchValue)
            );
  
            // Generate the HTML for the dropdown menu
            const dropdownMenu = $('#SearchDropdown');
            dropdownMenu.empty(); // Clear existing dropdown items
  
            // Populate the dropdown menu with the filtered users
            filteredBooks.forEach(book => {
              const dropdownItem = $('<a class="dropdown-item" href="#"></a>');
              dropdownItem.text(`${book.bookTitle}, ${book.bookID}`);
  
              // Add event listener to populate the search bar with the selected value
              dropdownItem.on('click', function() {
                $('#Searchbar').val($(this).text());
              });
  
              dropdownMenu.append(dropdownItem);
            });
  
            // Show or hide the dropdown menu based on the number of filtered users
            dropdownMenu.toggle(filteredBooks.length > 0);
          });
           // Hide the dropdown menu when clicking outside
           $(document).on('click', function(event) {
            const dropdownMenu = $('#SearchDropdown');
            if (!dropdownMenu.is(event.target) && dropdownMenu.has(event.target).length === 0) {
              dropdownMenu.hide();
            }
          });

           // Add event listener to the submit button
           $('form').on('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
  
            const searchValue = $('#Searchbar').val().toLowerCase();
            const bookIdRegex = /\b\d+\b/;
            const match = searchValue.match(bookIdRegex);
  
            let bookId = null;
            if (match) {
              bookId = match[0];
            }
  
            if (bookId) {
              // Make an AJAX request to fetch the filtered rental history data
              $.ajax({
                url: `/ReserveHistoryByBook?book_id=${bookId}`,
                method: 'GET',
                success: function(response) {
                  rentalHistory = response.rentalHistory;
                  console.log(rentalHistory);
  
                 
                  
                    updateRentalHistoryTable(rentalHistory);
                  
                   
                },
                error: function(error) {
                  console.error('Error fetching rental history:', error);
                }
              });
            } else {
              console.log('No book ID found in the search field');
              // Clear the rental history table
              rentalHistory = [];
              updateRentalHistoryTable([]);
            
            }
          });


        },
        error: function(error) {
          console.error('Error fetching books:', error);
        }
      });
    });
  }
  