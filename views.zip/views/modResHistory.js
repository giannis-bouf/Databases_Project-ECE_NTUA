$(document).ready(function (){
    const home_button = document.getElementById('modTitle');
    home_button.addEventListener('click', function() { window.location.href = 'modhome.html'; });
  
    $.ajax({
      url:'/ResHistory',
      method: 'GET',
      success: function(data) {
        const rowsData = data.ressDetails;
        console.log(rowsData);
    
        const RowContainer = document.querySelector('#RowContainer');
        RowContainer.innerHTML = '';
          for (let i = 0; i < rowsData.length; i++) {
          const row = rowsData[i];
    
          // Create a new row element
            const rowElement = createRowElement(row, i);
            RowContainer.appendChild(rowElement);

          
          // Append the row to the book container
        }
    
          function createRowElement(row, i) {
            const rowElement = document.createElement('tr');
            rowElement.innerHTML = `
            <th scope="row">${i+1}</th>
            <td>${row.first_name}</td>
            <td>${row.last_name}</td>
            <td>${row.title}</td>`;

            if (row.take_date) { rowElement.innerHTML += `<td>${row.take_date}</td>`;}
            else { rowElement.innerHTML += `<td></td>`; }

            rowElement.innerHTML += `<td>${row.status}</td>`;
      
          return rowElement;
      }
    },
      error: function(error) {
        console.log('Error fetching book data:', error);
      }
    });
  
    $('form').submit(function(event) {
      event.preventDefault(); // Prevent the form from submitting and reloading the page
      
      const name = $('#input_name').val(); // Get the selected author value from the dropdown
      const title = $('#input_title').val();
  
      // Perform the AJAX request with the input word as a query parameter
      $.ajax({
          url: '/RentalHistory',
          method: 'GET',
          data: { name: name || undefined,
                  title: title || undefined},
          success: function(data) {
        
            const rowsData = data.rentsDetails;
        console.log(rowsData);
    
        const RowContainer = document.querySelector('#RowContainer');
        RowContainer.innerHTML = '';
          for (let i = 0; i < rowsData.length; i++) {
          const row = rowsData[i];
    
          // Create a new row element
            const rowElement = createRowElement(row, i);
            RowContainer.appendChild(rowElement);

          
          // Append the row to the book container
        }
    
          function createRowElement(row, i) {
            const rowElement = document.createElement('tr');
            rowElement.innerHTML = `
            <th scope="row">${i+1}</th>
            <td>${row.first_name}</td>
            <td>${row.last_name}</td>
            <td>${row.title}</td>
            <td>${row.take_date}</td>
            <td>${row.status}</td>`
      
          return rowElement;
      }
        
          },
      error: function(error) {
        console.log('Error fetching book data:', error);
      }
      });
    });
})